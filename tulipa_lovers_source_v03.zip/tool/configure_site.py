#!/usr/bin/env python3
"""Set PUBLIC Supabase connection settings in deployed copy only. No service role secrets."""
import json
import os
from pathlib import Path
from urllib.parse import urlparse
url = os.getenv('TULIPA_SUPABASE_URL', '').strip().rstrip('/')
key = os.getenv('TULIPA_SUPABASE_PUBLISHABLE_KEY', '').strip()
path = Path('site/config.js')
assert path.is_file(), 'site/config.js missing'
if url or key:
    if not url or not key:
        raise SystemExit('Set BOTH TULIPA_SUPABASE_URL and TULIPA_SUPABASE_PUBLISHABLE_KEY')
    u = urlparse(url)
    if u.scheme != 'https' or not u.hostname or not u.hostname.endswith('.supabase.co'):
        raise SystemExit('TULIPA_SUPABASE_URL must be your https://PROJECT.supabase.co URL')
    if key.startswith('sb_secret_'):
        raise SystemExit('Never deploy Supabase SECRET key to public site')
    if not key.startswith('sb_publishable_'):
        raise SystemExit('Use ONLY an sb_publishable_ key; never use service_role, sb_secret_, or JWT secrets')
    data = 'export const CONFIG = {\n  SUPABASE_URL: ' + json.dumps(url) + ',\n  SUPABASE_PUBLISHABLE_KEY: ' + json.dumps(key) + ',\n};\n'
    path.write_text(data)
    print('Public Supabase settings applied to GitHub Pages site.')
else:
    print('Supabase not configured; storefront will remain demo/read-only.')
