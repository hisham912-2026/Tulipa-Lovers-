import {CONFIG} from './config.js';
export const online = Boolean(CONFIG.SUPABASE_URL && CONFIG.SUPABASE_PUBLISHABLE_KEY);
const base=(CONFIG.SUPABASE_URL||'').replace(/\/$/,'');
const key=CONFIG.SUPABASE_PUBLISHABLE_KEY;
const SESSION_KEY='tulipa.auth.session.v1';
export let session=(()=>{try{return JSON.parse(localStorage.getItem(SESSION_KEY))}catch{return null}})();
function save(s){session=s; if(s)localStorage.setItem(SESSION_KEY,JSON.stringify(s));else localStorage.removeItem(SESSION_KEY)}
async function request(path,{method='GET',body,auth=true,prefer}={}){
 if(!online)throw new Error('لم يتم ربط قاعدة البيانات حتى الآن');
 let token=auth?session?.access_token:null;
 if(auth && token && session.expires_at && Date.now() >= (session.expires_at-60)*1000){await refresh();token=session?.access_token}
 const headers={'apikey':key,'Content-Type':'application/json'};
 if(token)headers.Authorization=`Bearer ${token}`;
 if(prefer)headers.Prefer=prefer;
 let response=await fetch(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
 if(response.status===401 && auth && session?.refresh_token){await refresh();headers.Authorization=`Bearer ${session.access_token}`;response=await fetch(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)})}
 const raw=await response.text();let data;try{data=raw?JSON.parse(raw):null}catch{data=raw}
 if(!response.ok){throw new Error(data?.msg||data?.message||data?.error_description||data?.hint||data?.error||`تعذر الاتصال (${response.status})`)}
 return data;
}
export async function refresh(){if(!session?.refresh_token)return;const data=await request('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:session.refresh_token},auth:false});save({...data,expires_at:Math.floor(Date.now()/1000)+data.expires_in});return session}
export async function sendPhoneOTP(phone){return request('/auth/v1/otp',{method:'POST',body:{phone,create_user:true},auth:false})}
export async function verifyPhoneOTP(phone,token){const data=await request('/auth/v1/verify',{method:'POST',body:{phone,token,type:'sms'},auth:false});save({...data,expires_at:Math.floor(Date.now()/1000)+data.expires_in});return data}
export async function changeEmail(email){return request('/auth/v1/user',{method:'PUT',body:{email}})}
export async function signOut(){try{if(session)await request('/auth/v1/logout',{method:'POST'})}finally{save(null)}}
export const currentUser=()=>session?.user||null;
export async function getProfile(){const id=currentUser()?.id;if(!id)return null;const a=await request(`/rest/v1/profiles?id=eq.${encodeURIComponent(id)}&select=*`);return a?.[0]||null}
export async function updateProfile(full_name){const id=currentUser()?.id;return request(`/rest/v1/profiles?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:{full_name},prefer:'return=representation'})}
export async function getProducts(){return request('/rest/v1/products?select=*&order=created_at.desc')}
export async function getOrders(){return request('/rest/v1/orders?select=*,order_items(*)&order=created_at.desc')}
export async function getLoyalty(){return request('/rest/v1/loyalty_ledger?select=*&order=created_at.desc')}
export async function submitOrder(payload){return request('/rest/v1/rpc/submit_order',{method:'POST',body:payload})}
export async function getEvents(){return request('/rest/v1/event_requests?select=*&order=created_at.desc')}
export async function addEvent(event){return request('/rest/v1/event_requests',{method:'POST',body:event,prefer:'return=representation'})}
export async function adminGetCustomers(){return request('/rest/v1/profiles?select=id,full_name,phone,email,role,created_at&order=created_at.desc')}
export async function adminUpsertProduct(data,id){return request(id?`/rest/v1/products?id=eq.${encodeURIComponent(id)}`:'/rest/v1/products',{method:id?'PATCH':'POST',body:data,prefer:'return=representation'})}
export async function adminSetOrderStatus(id,patch){return request(`/rest/v1/orders?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:patch,prefer:'return=representation'})}
export async function adminSetEventStatus(id,status){return request(`/rest/v1/event_requests?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:{status},prefer:'return=representation'})}
