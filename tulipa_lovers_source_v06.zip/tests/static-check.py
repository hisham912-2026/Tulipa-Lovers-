from pathlib import Path
p=Path(__file__).resolve().parents[1]
sql=(p/'supabase/01_init.sql').read_text()
for table in ['profiles','products','orders','order_items','loyalty_ledger','event_requests']:
    assert f'ALTER TABLE public.{table} ENABLE ROW LEVEL SECURITY;' in sql, table
assert 'GRANT UPDATE(full_name) ON public.profiles' in sql
assert 'SET role=\'owner\'' in sql
assert 'CREATE FUNCTION public.submit_order' in sql
assert 'SECURITY INVOKER' in sql
assert 'stock_qty=stock_qty-v_qty' in sql
assert 'payment_status=\'paid\'' in sql
assert "SUPABASE_URL: ''" in (p/'site/config.js').read_text() and "SUPABASE_PUBLISHABLE_KEY: ''" in (p/'site/config.js').read_text()
assert '.github/workflows/deploy-pages.yml' in [str(k.relative_to(p)) for k in p.rglob('*') if k.is_file()]
print('PASS static checks: RLS all exposed tables, pricing/order RPC, no configured credentials, deployment workflow.')

img_sql=(p/'supabase/02_product_images.sql').read_text()
assert 'tulipa_owner_insert_product_images' in img_sql and 'private.is_owner()' in img_sql
assert 'FOR INSERT TO authenticated' in img_sql and 'storage.buckets' in img_sql
print('PASS v0.6 upload bucket and owner-only RLS policy definitions.')
