import {CONFIG} from './config.js';
export const online = Boolean(CONFIG.SUPABASE_URL && CONFIG.SUPABASE_PUBLISHABLE_KEY);
const base=(CONFIG.SUPABASE_URL||'').replace(/\/$/,'');
const key=CONFIG.SUPABASE_PUBLISHABLE_KEY;
const SESSION_KEY='tulipa.auth.session.v1';
export let session=(()=>{try{return JSON.parse(localStorage.getItem(SESSION_KEY))}catch{return null}})();
function save(s){session=s; if(s)localStorage.setItem(SESSION_KEY,JSON.stringify(s));else localStorage.removeItem(SESSION_KEY)}
async function request(path,{method='GET',body,auth=true,prefer}={}){
 if(!online)throw new Error('لم يتم ربط قاعدة البيانات حتى الآن');
 let token=auth?session?.access_token:null;
 if(auth && token && session.expires_at && Date.now() >= (session.expires_at-60)*1000){await refresh();token=session?.access_token}
 const headers={'apikey':key,'Content-Type':'application/json'};
 if(token)headers.Authorization=`Bearer ${token}`;
 if(prefer)headers.Prefer=prefer;
 let response=await fetch(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
 if(response.status===401 && auth && session?.refresh_token){await refresh();headers.Authorization=`Bearer ${session.access_token}`;response=await fetch(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)})}
 const raw=await response.text();let data;try{data=raw?JSON.parse(raw):null}catch{data=raw}
 if(!response.ok){throw new Error(data?.msg||data?.message||data?.error_description||data?.hint||data?.error||`تعذر الاتصال (${response.status})`)}
 return data;
}
export async function refresh(){if(!session?.refresh_token)return;const data=await request('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:session.refresh_token},auth:false});save({...data,expires_at:Math.floor(Date.now()/1000)+data.expires_in});return session}
// Email + password auth for trial use. Supabase's default email service may only
// send confirmation emails to organization team addresses. Keep confirmation on.
export async function signUpWithEmail(email,password,full_name){
 const data=await request('/auth/v1/signup',{method:'POST',body:{email,password,data:{full_name}},auth:false});
 if(data?.access_token)save({...data,expires_at:Math.floor(Date.now()/1000)+Number(data.expires_in||3600)});
 return data;
}
export async function signInWithEmail(email,password){
 const data=await request('/auth/v1/token?grant_type=password',{method:'POST',body:{email,password},auth:false});
 if(!data?.access_token||!data?.user)throw new Error('تعذر إكمال تسجيل الدخول');
 save({...data,expires_at:Math.floor(Date.now()/1000)+Number(data.expires_in||3600)});
 return data;
}
export async function requestPasswordReset(email){
 return request('/auth/v1/recover',{method:'POST',body:{email},auth:false});
}
export async function updatePassword(password){
 return request('/auth/v1/user',{method:'PUT',body:{password}});
}
// The implicit confirmation/recovery redirect returns access and refresh tokens
// in the URL fragment. Validate the received token with Supabase, then erase
// tokens from the address bar before rendering any account information.
export async function consumeAuthRedirect(){
 const hash=window.location.hash||'';
 if(!hash.startsWith('#access_token=') && !/^#(?:type|refresh_token|expires_in)=/.test(hash) && !hash.startsWith('#error=')&&!hash.startsWith('#error_code='))return null;
 const params=new URLSearchParams(hash.slice(1));
 if(!params.has('access_token')&&!params.has('error')&&!params.has('error_code'))return null;
 const cleanUrl=window.location.pathname+window.location.search+'#/account';
 if(window.history?.replaceState)window.history.replaceState(null,'',cleanUrl);
 else window.location.hash='#/account';
 if(params.get('error')||params.get('error_code'))return {error:params.get('error_description')||'رابط التأكيد غير صالح أو انتهت صلاحيته'};
 const access_token=params.get('access_token'),refresh_token=params.get('refresh_token');
 if(!access_token||!refresh_token)return {error:'بيانات التأكيد غير مكتملة'};
 const provisional={access_token,refresh_token,token_type:params.get('token_type')||'bearer',expires_in:Number(params.get('expires_in'))||3600,expires_at:Math.floor(Date.now()/1000)+(Number(params.get('expires_in'))||3600)};
 save(provisional);
 try{
  const user=await request('/auth/v1/user');
  if(!user?.id)throw new Error('تعذر التحقق من جلسة المستخدم');
  save({...provisional,user});
  return {type:params.get('type')||'signup'};
 }catch(e){save(null);return {error:e.message}}
}
export async function changeEmail(email){return request('/auth/v1/user',{method:'PUT',body:{email}})}
export async function signOut(){try{if(session)await request('/auth/v1/logout',{method:'POST'})}finally{save(null)}}
export const currentUser=()=>session?.user||null;
export async function getProfile(){const id=currentUser()?.id;if(!id)return null;const a=await request(`/rest/v1/profiles?id=eq.${encodeURIComponent(id)}&select=*`);return a?.[0]||null}
export async function updateProfile(full_name){const id=currentUser()?.id;return request(`/rest/v1/profiles?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:{full_name},prefer:'return=representation'})}
export async function getProducts(){return request('/rest/v1/products?select=*&order=created_at.desc')}
export async function getOrders(){return request('/rest/v1/orders?select=*,order_items(*)&order=created_at.desc')}
export async function getLoyalty(){return request('/rest/v1/loyalty_ledger?select=*&order=created_at.desc')}
export async function submitOrder(payload){return request('/rest/v1/rpc/submit_order',{method:'POST',body:payload})}
export async function getEvents(){return request('/rest/v1/event_requests?select=*&order=created_at.desc')}
export async function addEvent(event){return request('/rest/v1/event_requests',{method:'POST',body:event,prefer:'return=representation'})}
export async function adminGetCustomers(){return request('/rest/v1/profiles?select=id,full_name,phone,email,role,created_at&order=created_at.desc')}
export async function adminUpsertProduct(data,id){const result=await request(id?`/rest/v1/products?id=eq.${encodeURIComponent(id)}`:'/rest/v1/products',{method:id?'PATCH':'POST',body:data,prefer:'return=representation'});if(!Array.isArray(result)||result.length!==1)throw new Error('لم يتم حفظ المنتج في قاعدة البيانات. تحقق من صلاحية المالك ثم أعد المحاولة.');return result[0]}
export async function adminSetOrderStatus(id,patch){return request(`/rest/v1/orders?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:patch,prefer:'return=representation'})}
export async function adminSetEventStatus(id,status){return request(`/rest/v1/event_requests?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:{status},prefer:'return=representation'})}

// Public storefront images live in a dedicated Supabase Storage bucket.
// Store only a validated relative object path in public.products.image_path.
const IMAGE_UPLOAD_PATH = /^uploads\/[a-f0-9-]{36}\.(?:jpg|jpeg|png|webp)$/i;
const LOCAL_IMAGE_NAME = /^[a-zA-Z0-9_.-]+\.(?:jpg|jpeg|png|webp)$/i;
export function productImageUrl(path){
 const name=typeof path==='string'?path:'bouquet_rose.jpg';
 if(IMAGE_UPLOAD_PATH.test(name) && online) return `${base}/storage/v1/object/public/product-images/${name}`;
 if(LOCAL_IMAGE_NAME.test(name))return `images/${encodeURIComponent(name)}`;
 return 'images/bouquet_rose.jpg';
}
export async function adminUploadProductImage(file){
 if(!online)throw new Error('لم يتم الاتصال بقاعدة البيانات');
 if(!currentUser()||!session?.access_token)throw new Error('يجب تسجيل الدخول بصلاحية المالك قبل رفع الصور');
 if(!file||typeof file.size!=='number'||file.size===0)throw new Error('اختر صورة صحيحة');
 const types={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
 const extension=types[file.type];
 if(!extension)throw new Error('نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WebP فقط');
 if(file.size>5*1024*1024)throw new Error('يجب ألا يتجاوز حجم الصورة 5 ميجابايت');
 if(session.expires_at && Date.now()>=(session.expires_at-60)*1000)await refresh();
 const objectPath=`uploads/${crypto.randomUUID()}.${extension}`;
 const response=await fetch(`${base}/storage/v1/object/product-images/${objectPath}`,{
   method:'POST',
   headers:{apikey:key,Authorization:`Bearer ${session.access_token}`,'Content-Type':file.type,'Cache-Control':'3600','x-upsert':'false'},
   body:file
 });
 if(!response.ok){
   let error;try{error=await response.json()}catch{error=null}
   throw new Error(error?.message||error?.error||`فشل رفع الصورة (${response.status}). تحقق من تنفيذ ملف إعداد Storage وصلاحيات المالك.`);
 }
 return objectPath;
}
