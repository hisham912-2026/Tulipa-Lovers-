import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';

// Regression: form.controls['id'] shadows the form.id DOM property.
// The save handler must read form.getAttribute('id'), not form.id.
const dir=await mkdtemp(join(tmpdir(),'tulipa-product-save-'));
try {
 await writeFile(join(dir,'package.json'),' {"type":"module"} ');
 await writeFile(join(dir,'app.js'),await readFile(new URL('../site/app.js',import.meta.url)));
 const records=[{id:'4a2cdaf0-5ee4-49cc-a99f-000000000001',sku:'TL-001',title_ar:'بوكيه توليبا كلاسيك',description_ar:'اختبار',category:'bouquets',kind:'fixed',price_sar:249,stock_qty:0,image_path:'bouquet_white.jpg',active:false,featured:false}];
 const writes=[];
 const mock={online:true,currentUser:()=>({id:'owner1',email:'owner@example.com'}),consumeAuthRedirect:async()=>null,
 getProducts:async()=>records,getProfile:async()=>({id:'owner1',role:'owner'}),getOrders:async()=>[],getLoyalty:async()=>[],getEvents:async()=>[],
 adminUpsertProduct:async(data,id)=>{writes.push({data,id});Object.assign(records[0],data);return records[0]}};
 await writeFile(join(dir,'api.js'),`export const online=true; export const currentUser=()=>({id:'owner1'});export const consumeAuthRedirect=async()=>null;export const getProducts=async()=>globalThis.__mock.records;export const getProfile=async()=>({id:'owner1',role:'owner'});export const getOrders=async()=>[];export const getLoyalty=async()=>[];export const getEvents=async()=>[];export const adminUpsertProduct=async(data,id)=>globalThis.__mock.adminUpsertProduct(data,id);`);
 globalThis.__mock={records,adminUpsertProduct:mock.adminUpsertProduct};
 const store=new Map();
 globalThis.localStorage={getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
 const elements=new Map(),handlers={};
 globalThis.document={getElementById(id){if(!elements.has(id))elements.set(id,{innerHTML:'',appendChild(){}});return elements.get(id)},addEventListener(k,cb){handlers[k]=cb},createElement(){return {className:'',textContent:'',remove(){}}}};
 globalThis.window={location:{hash:'#/admin'},scrollTo(){}};
 globalThis.location={protocol:'file:'};
 const fvals={id:records[0].id,sku:'TL-001',title_ar:'بوكيه توليبا كلاسيك - اختبار',description_ar:'اختبار',category:'bouquets',kind:'fixed',price_sar:'249',stock_qty:'0',image_path:'bouquet_white.jpg'};
 globalThis.FormData=class {constructor(form){this.values=form.values;}get(k){return this.values[k]??null}has(k){return Object.hasOwn(this.values,k)}};
 await import(pathToFileURL(join(dir,'app.js')).href);
 await new Promise(resolve=>setTimeout(resolve,50));
 await handlers.click({target:{closest:()=>({dataset:{adminTab:'products'},hasAttribute:name=>name==='data-admin-tab'})}});
 assert.match(elements.get('app').innerHTML,/productForm/);
 const button={disabled:false,textContent:'حفظ المنتج'};
 let prevented=false;
 const form={id:{name:'id',value:records[0].id},getAttribute:name=>name==='id'?'productForm':null,querySelector:()=>button,values:fvals};
 await handlers.submit({target:form,preventDefault(){prevented=true}});
 assert(prevented,'form submit should be intercepted');
 assert.equal(writes.length,1,'saving existing product must invoke database API once');
 assert.equal(writes[0].id,records[0].id);
 assert.equal(writes[0].data.title_ar,'بوكيه توليبا كلاسيك - اختبار');
 assert.equal(writes[0].data.active,false);
 assert.match(elements.get('app').innerHTML,/بوكيه توليبا كلاسيك - اختبار/);
 assert.equal(button.disabled,false);
 console.log('PASS product save: form ID is not shadowed by the hidden input; owner PATCH fires once and reloads product.');
}finally {delete globalThis.__mock;await rm(dir,{recursive:true,force:true})}
