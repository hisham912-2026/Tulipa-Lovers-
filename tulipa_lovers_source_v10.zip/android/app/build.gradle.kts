plugins { id("com.android.application") }
val site = providers.gradleProperty("tulipaWebUrl").orElse("https://hisham912-2026.github.io/Tulipa-Lovers-/").get()
android {
 namespace = "com.tulipalovers.live"
 compileSdk = 35
 defaultConfig {
  applicationId = "com.tulipalovers.live"
  minSdk = 26
  targetSdk = 35
  versionCode = 3
  versionName = "0.3.0"
  buildConfigField("String", "WEB_URL", "\"${site.replace("\\", "\\\\").replace("\"", "\\\"")}\"")
 }
 buildFeatures { buildConfig = true }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
