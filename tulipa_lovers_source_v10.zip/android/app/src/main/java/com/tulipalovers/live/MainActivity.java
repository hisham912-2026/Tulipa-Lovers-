package com.tulipalovers.live;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

/** Android shell for the SAME real storefront hosted on GitHub Pages.
 * The shop's backend is Supabase, not GitHub. No credentials stored in the APK. */
public final class MainActivity extends Activity {
  private WebView webView;
  private String allowedHost;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(64, 89, 103));
    getWindow().setNavigationBarColor(Color.WHITE);
    Uri site = Uri.parse(BuildConfig.WEB_URL);
    if (!"https".equals(site.getScheme()) || site.getHost()==null) {
      throw new IllegalStateException("Store URL must be HTTPS");
    }
    allowedHost = site.getHost();
    webView = new WebView(this);
    WebSettings s=webView.getSettings();
    s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);s.setAllowContentAccess(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);
    webView.setWebChromeClient(new WebChromeClient());
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri=request.getUrl();
        if("https".equals(uri.getScheme()) && allowedHost.equals(uri.getHost()))return false;
        try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
        return true;
      }
    });
    setContentView(webView);
    webView.loadUrl(BuildConfig.WEB_URL);
  }
  @Override public void onBackPressed() {
    if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
  }
  @Override protected void onDestroy() {if(webView!=null)webView.destroy();super.onDestroy();}
}
