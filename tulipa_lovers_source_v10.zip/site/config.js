// PUBLIC config only. Configure with Supabase Project URL + PUBLISHABLE key.
// Never paste a service_role key or secret in this file or GitHub.
export const CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_PUBLISHABLE_KEY: '',
  PAYMENTS_TEST_ENABLED: false,
};
