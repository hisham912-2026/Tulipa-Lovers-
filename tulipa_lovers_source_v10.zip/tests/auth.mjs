import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
const d=await mkdtemp(join(tmpdir(),'tulipa-auth-'));
try{
 await writeFile(join(d,'package.json'),'{"type":"module"}');
 await writeFile(join(d,'config.js'),"export const CONFIG={SUPABASE_URL:'https://test.supabase.co',SUPABASE_PUBLISHABLE_KEY:'sb_publishable_test_only'};");
 await writeFile(join(d,'api.js'),await readFile(new URL('../site/api.js',import.meta.url)));
 const db=new Map();
 globalThis.localStorage={getItem:k=>db.get(k)||null,setItem:(k,v)=>db.set(k,v),removeItem:k=>db.delete(k)};
 const calls=[];
 globalThis.fetch=async (url,options)=>{
  const path=new URL(url).pathname;
  calls.push({path,opts:options,body:options?.body?JSON.parse(options.body):null});
  const response={
   '/auth/v1/signup':{user:{id:'u1',email:'test@example.com'},access_token:null},
   '/auth/v1/token':{access_token:'signin-access',refresh_token:'signin-refresh',expires_in:3600,user:{id:'u1',email:'test@example.com'}},
   '/auth/v1/recover':{},
   '/auth/v1/user':options.method==='PUT'?{id:'u1'}:{id:'u1',email:'test@example.com'},
  }[path] || {};
  return {ok:true,status:200,text:async()=>JSON.stringify(response)};
 };
 let path='/Tulipa-Lovers/',search='',hash='';
 const win={history:{replaceState(_state,_title,url){assert.equal(url,'/Tulipa-Lovers/#/account');hash='#/account';}},location:{pathname:path,search,get hash(){return hash},set hash(h){hash=h}}};
 globalThis.window=win;
 const api=await import(pathToFileURL(join(d,'api.js')).href);
 assert(api.online);
 const signup=await api.signUpWithEmail('test@example.com','sample-safepass','متجر توليبا');
 assert.equal(signup.access_token,null);
 assert.equal(api.currentUser(),null);
 assert.equal(calls[0].body.data.full_name,'متجر توليبا');
 assert.equal(calls[0].body.password,'sample-safepass');
 assert.equal(db.size,0,'signup without email confirmation must not log user in');
 await api.signInWithEmail('test@example.com','sample-safepass');
 assert.equal(api.currentUser().email,'test@example.com');
 assert.equal(calls[1].path,'/auth/v1/token');
 await api.requestPasswordReset('test@example.com');
 assert.equal(calls[2].path,'/auth/v1/recover');
 await api.updatePassword('another-pass-10');
 assert.equal(calls[3].body.password,'another-pass-10');
 hash='#access_token=confirmed-token&refresh_token=confirmed-refresh&expires_in=3600&type=recovery';
 const result=await api.consumeAuthRedirect();
 assert.equal(result.type,'recovery');
 assert.equal(api.currentUser().id,'u1');
 assert.equal(hash,'#/account');
 assert(!hash.includes('token'), 'do not leave any token in visible URL');
 await api.signOut();assert.equal(api.currentUser(),null);
 console.log('PASS email signup awaiting confirmation, password login, recovery, callback and logout');
}finally{await rm(d,{recursive:true,force:true});}
