# Tulipa Lovers — الإصدار 0.4: تسجيل البريد الإلكتروني للمرحلة التجريبية

هذا الإصدار يستبدل تسجيل SMS بالتسجيل باستخدام **البريد الإلكتروني وكلمة المرور**، مع دعم رسالة تأكيد البريد وتسجيل الدخول واستعادة كلمة المرور.

## نشر التحديث على GitHub

1. ارفع `tulipa_lovers_source_v04.zip` إلى جذر المستودع `hisham912-2026/Tulipa-Lovers-` دون فك الضغط.
2. استبدل `.github/workflows/build_tulipa_from_zip.yml` بملف الأكشن المحدث المرفق مع هذا الإصدار.
3. أبقِ Variables الحاليين (`TULIPA_SUPABASE_URL` و`TULIPA_SUPABASE_PUBLISHABLE_KEY`) كما هما؛ لا تستخدم secret/service_role في GitHub Pages.
4. من Actions شغّل `Tulipa Lovers - Build APK and Deploy Shop from ZIP` وتحقق من مهمتي Android وPages.
5. إصدار `app-debug.apk` اختبار فقط؛ التطبيق Android WebView يفتح الموقع نفسه، والتحديث يُنشر للويب فورًا.

## إعداد Supabase Auth — مشروع توليبا فقط

1. من Authentication → Sign In / Providers → Email: فعّل Email provider واسمح بإنشاء الحسابات. **أبقِ Confirm Email مفعّلًا**.
2. من Authentication → URL Configuration:
   - Site URL: `https://hisham912-2026.github.io/Tulipa-Lovers-/`
   - Redirect URLs: أضف العنوان نفسه بدقة.
3. خدمة بريد Supabase الافتراضية محدودة جدًا: تصل رسائلها إلى أعضاء فريق المشروع المخوّلين فقط، وحد الإرسال عادة رسالتان في الساعة. لا تختبر ببريد عميل خارجي ولا تعطل Confirm Email كحل لهذه القيود. للإطلاق التجاري تحتاج Custom SMTP وخطوات مكافحة إساءة الاستخدام.
4. أنشئ حسابك عبر صفحة **حسابي → حساب جديد** ثم أكّد البريد. لتفعيل المالك، استخدم SQL Editor على مشروع توليبا بعد حصولك على UUID الحقيقي من Authentication → Users:

```sql
UPDATE public.profiles
SET role='owner'
WHERE id = 'REPLACE_WITH_OWNER_AUTH_USER_UUID'::uuid;
```

5. افحص RLS واختبر سلة/طلب على بيانات اختبارية فقط. المنتجات والأسعار والمخزون في SQL الأصلي تجريبية وغير مفعّلة.

## حدود مهمة

- الإيميل موثق عند التأكيد فقط؛ **رقم الجوال في بيانات التوصيل غير موثق**، وليس هناك OTP SMS.
- لا تدفع ولا تطلب خدمة SMS الآن.
- هذا الإصدار لا يتضمن مدفوعات إلكترونية، ولا تشغيلًا تجاريًا قبل سياسات الخصوصية وضبط SMTP ونشر المنتجات المعتمدة.
- تنفيذ SQL الأساسي `supabase/01_init.sql` تم سابقًا، فلا تعِد تشغيله لأنه ينشئ جداول موجودة بالفعل. **لا حاجة إلى SQL جديد لإضافة التسجيل بالبريد.**
