# Tulipa Lovers — إعداد إصدار Android من ZIP (V0.3)

هذا البناء يستخدم نمط مشروع «المرافق الرقمي للحاج» السابق: ملف مصدر ZIP في جذر المستودع + ملف GitHub Action داخل `.github/workflows`.

**اسم مستودع GitHub المعتمد**: `hisham912-2026/Tulipa-Lovers-`.
**الرابط الذي سيفتحه APK**: `https://hisham912-2026.github.io/Tulipa-Lovers-/`.
**الواجهة الفعلية**: PWA داخل WebView؛ ليس تطبيق Kotlin Compose أصليًا ولا يوجد باك اند على GitHub.
**الخادم**: Supabase منفصل للمحل، ولم يتم توصيله بعد.

## آلية العمل
1. ارفع `tulipa_lovers_source_v03.zip` إلى جذر مستودع GitHub.
2. أنشئ `.github/workflows/build_tulipa_from_zip.yml` عبر الملف المنفصل الذي سيصلك مع الحزمة.
3. افتح Settings > Pages > Source: GitHub Actions.
4. من Actions شغّل `Tulipa Lovers - Build APK and Deploy Shop from ZIP` باستخدام Run workflow على main.
5. سيكون هناك مهمتان مستقلتان: `Build Android debug APK` و `Deploy storefront to GitHub Pages`.
6. عند نجاح البناء حمّل Artifact باسم `Tulipa-Lovers-debug-APK-v0.3` واستخْرج `app-debug.apk` مع ملف SHA256.

## ربط Supabase بدون إعادة رفع ZIP
أنشئ مشروع Supabase مستقلًا ثم شغّل الملف `supabase/01_init.sql` بعد مراجعة SQL وأمان قواعد البيانات.
في GitHub > Settings > Secrets and variables > Actions > Variables ضع:
- `TULIPA_SUPABASE_URL` = رابط مشروع Supabase العام مثل https://PROJECT.supabase.co
- `TULIPA_SUPABASE_PUBLISHABLE_KEY` = مفتاح publishable فقط، لا تضع `service_role` أو secret.
ثم أعد تشغيل Workflow. يحتاج تسجيل الهاتف إعداد مزود SMS في Supabase.

**قيود الإصدار:** الصور والأسعار توضيحية، والطلبات الحقيقية لن تعمل قبل تفعيل Supabase وتأمينه ومراجعة الأسعار والمنتجات وسياسة الخصوصية. ليس هناك دفع إلكتروني مفعّل. إصدار APK تجريبي Debug وليس إصدار Google Play معتمَدًا.
