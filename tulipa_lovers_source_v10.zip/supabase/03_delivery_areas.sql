-- Tulipa Lovers v0.7 / رسوم التوصيل حسب أحياء ومناطق الطائف
-- شغّل هذا الملف مرة واحدة داخل مشروع Tulipa-Lovers فقط، بعد ملف v0.6.
-- لا يغيّر قيمة رسوم الطلبات السابقة أو حسابات الحج؛ لا توجد رسوم أو أحياء افتراضية نشطة.
BEGIN;
CREATE TABLE IF NOT EXISTS public.delivery_areas (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name_ar text NOT NULL UNIQUE CHECK (char_length(btrim(name_ar)) BETWEEN 2 AND 120 AND name_ar=btrim(name_ar)),
 fee_sar numeric(12,2) NOT NULL CHECK (fee_sar BETWEEN 0 AND 500),
 active boolean NOT NULL DEFAULT false,
 sort_order integer NOT NULL DEFAULT 100 CHECK (sort_order BETWEEN 0 AND 9999),
 created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.delivery_areas ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.delivery_areas FROM anon, authenticated;
GRANT SELECT ON public.delivery_areas TO anon, authenticated;
GRANT INSERT, UPDATE ON public.delivery_areas TO authenticated;
-- أسماء الأحياء والرسوم المفعلة فقط متاحة للزوار.
CREATE POLICY tulipa_delivery_active_read ON public.delivery_areas FOR SELECT TO anon, authenticated USING (active=true);
CREATE POLICY tulipa_delivery_owner_read ON public.delivery_areas FOR SELECT TO authenticated USING ((SELECT private.is_owner()));
CREATE POLICY tulipa_delivery_owner_insert ON public.delivery_areas FOR INSERT TO authenticated WITH CHECK ((SELECT private.is_owner()));
CREATE POLICY tulipa_delivery_owner_update ON public.delivery_areas FOR UPDATE TO authenticated USING ((SELECT private.is_owner())) WITH CHECK ((SELECT private.is_owner()));
-- إضافة حقل اختياري للطلبات الجديدة. الطلبات السابقة تظل كما هي برسومها التاريخية.
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_area_id uuid REFERENCES public.delivery_areas(id) ON DELETE RESTRICT;
ALTER TABLE public.orders ALTER COLUMN delivery_sar SET DEFAULT 0;
CREATE INDEX IF NOT EXISTS ix_orders_delivery_area ON public.orders(delivery_area_id);

-- استبدال دالة الطلب الحالية مع الحفاظ على نفس توقيع RPC للعملاء الحاليين.
CREATE OR REPLACE FUNCTION private.place_order(
 p_request_id uuid, p_items jsonb, p_recipient_name text, p_recipient_phone text,
 p_district text, p_address text, p_delivery_at timestamptz,
 p_customer_note text DEFAULT '', p_redeem_points integer DEFAULT 0
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
 v_user uuid := auth.uid(); v_order uuid; v_existing uuid;
 v_line jsonb; v_product public.products%ROWTYPE; v_qty int; v_price numeric(12,2);
 v_subtotal numeric(12,2):=0; v_delivery numeric(12,2):=0;
 v_area public.delivery_areas%ROWTYPE; v_discount numeric(12,2):=0;
 v_custom jsonb; v_flower text; v_wrap text; v_stems int; v_card boolean;
 v_review boolean:=false; v_points integer:=0; v_total_items int:=0;
BEGIN
 IF v_user IS NULL THEN RAISE EXCEPTION 'Login required'; END IF;
 IF p_request_id IS NULL THEN RAISE EXCEPTION 'Missing request ID'; END IF;
 PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext(v_user::text)::bigint);
 SELECT id INTO v_existing FROM public.orders WHERE customer_id=v_user AND request_id=p_request_id;
 IF v_existing IS NOT NULL THEN RETURN v_existing; END IF;
 IF p_items IS NULL OR pg_catalog.jsonb_typeof(p_items) <> 'array' OR pg_catalog.jsonb_array_length(p_items) NOT BETWEEN 1 AND 20 THEN
  RAISE EXCEPTION 'Choose 1–20 items';
 END IF;
 IF pg_catalog.char_length(pg_catalog.btrim(coalesce(p_recipient_name,''))) NOT BETWEEN 2 AND 120
    OR coalesce(p_recipient_phone,'') !~ '^\+9665[0-9]{8}$'
    OR pg_catalog.char_length(pg_catalog.btrim(coalesce(p_district,''))) NOT BETWEEN 2 AND 120
    OR pg_catalog.char_length(pg_catalog.btrim(coalesce(p_address,''))) NOT BETWEEN 5 AND 300
    OR pg_catalog.char_length(coalesce(p_customer_note,'')) > 500 THEN RAISE EXCEPTION 'Invalid delivery information'; END IF;
 -- The zone and fee must be selected by the server from owner-managed public records.
 -- The storefront does not send or control delivery_sar.
 SELECT * INTO v_area
 FROM public.delivery_areas
 WHERE name_ar=pg_catalog.btrim(p_district) AND active=true
 FOR SHARE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Delivery is not available for the selected area'; END IF;
 v_delivery:=v_area.fee_sar;
 IF p_delivery_at IS NULL OR p_delivery_at < now()+ interval '2 hours' OR p_delivery_at > now()+ interval '60 days' THEN
  RAISE EXCEPTION 'Delivery slot outside allowed window'; END IF;
 IF p_redeem_points IS NULL OR p_redeem_points < 0 OR mod(p_redeem_points,100)<>0 THEN
  RAISE EXCEPTION 'Loyalty redemption requires 100-point increments'; END IF;
 INSERT INTO public.orders(request_id,customer_id,recipient_name,recipient_phone,district,delivery_area_id,address_text,delivery_at,customer_note)
 VALUES(p_request_id,v_user,pg_catalog.btrim(p_recipient_name),p_recipient_phone,v_area.id,pg_catalog.btrim(p_address),p_delivery_at,coalesce(p_customer_note,''))
 RETURNING id INTO v_order;
 FOR v_line IN SELECT value FROM pg_catalog.jsonb_array_elements(p_items) LOOP
  IF pg_catalog.jsonb_typeof(v_line) <> 'object' OR v_line->>'product_id' IS NULL THEN RAISE EXCEPTION 'Invalid cart item'; END IF;
  v_qty := (v_line->>'quantity')::int;
  IF v_qty NOT BETWEEN 1 AND 10 THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
  v_total_items:=v_total_items+v_qty;
  IF v_total_items > 50 THEN RAISE EXCEPTION 'Maximum 50 pieces per order'; END IF;
  SELECT * INTO v_product FROM public.products WHERE id=(v_line->>'product_id')::uuid AND active=true FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Product unavailable'; END IF;
  v_custom := coalesce(v_line->'customization','{}'::jsonb);
  IF pg_catalog.jsonb_typeof(v_custom)<>'object' THEN RAISE EXCEPTION 'Invalid options'; END IF;
  IF v_product.kind='custom' THEN
   v_flower:=v_custom->>'flower'; v_wrap:=v_custom->>'wrap'; v_stems:=(v_custom->>'stems')::int;
   v_card:=coalesce((v_custom->>'card')::boolean,false);
   IF v_flower NOT IN ('rose','tulip','lily') OR v_wrap NOT IN ('classic','luxury','box')
      OR v_stems NOT IN (10,15,25,50) THEN RAISE EXCEPTION 'Unsupported bouquet configuration'; END IF;
   v_custom:=pg_catalog.jsonb_build_object('flower',v_flower,'wrap',v_wrap,'stems',v_stems,'card',v_card);
   v_price:=v_stems * (CASE v_flower WHEN 'rose' THEN 12 WHEN 'tulip' THEN 17 ELSE 22 END)
    + (CASE v_wrap WHEN 'classic' THEN 15 WHEN 'luxury' THEN 30 ELSE 45 END)
    + (CASE WHEN v_card THEN 10 ELSE 0 END);
   v_review:=true; -- Flower-component stock checked by florist before accepting custom work.
  ELSE
   IF v_custom <> '{}'::jsonb THEN RAISE EXCEPTION 'Fixed bouquet cannot accept custom pricing'; END IF;
   IF v_product.stock_qty < v_qty THEN RAISE EXCEPTION 'Not enough stock: %', v_product.title_ar; END IF;
   UPDATE public.products SET stock_qty=stock_qty-v_qty WHERE id=v_product.id;
   v_price:=v_product.price_sar;
  END IF;
  INSERT INTO public.order_items(order_id,product_id,product_title,quantity,unit_price_sar,customization)
  VALUES(v_order,v_product.id,v_product.title_ar,v_qty,v_price,v_custom);
  v_subtotal:=v_subtotal+v_price*v_qty;
 END LOOP;
 IF p_redeem_points>0 THEN
  SELECT coalesce(sum(points_delta),0) INTO v_points FROM public.loyalty_ledger WHERE user_id=v_user;
  IF v_points < p_redeem_points THEN RAISE EXCEPTION 'Insufficient loyalty points'; END IF;
  v_discount:=p_redeem_points / 20.0;
  IF v_discount > v_subtotal * 0.20 THEN RAISE EXCEPTION 'Loyalty discount exceeds 20 percent'; END IF;
  INSERT INTO public.loyalty_ledger(user_id,order_id,points_delta,reason)
  VALUES(v_user,v_order,-p_redeem_points,'redeemed');
 END IF;
 UPDATE public.orders SET subtotal_sar=v_subtotal,delivery_sar=v_delivery,discount_sar=v_discount,
 total_sar=v_subtotal+v_delivery-v_discount,redeemed_points=p_redeem_points,
 status=(CASE WHEN v_review THEN 'pending_review' ELSE 'pending' END)
 WHERE id=v_order;
 RETURN v_order;
END; $$;

-- اسم الحي هو معرّف التسعير المعتمد حاليًا؛ يجب أن يتطابق مع سجل مفعّل.
-- لا يُسمح للمتصفح بتغيير السعر، ولا تقبل الدالة أحياءً غير مفعلة.
COMMIT;
