-- TULIPA LOVERS v0.6 - IMAGE STORAGE ONLY; apply in Tulipa-Lovers Supabase project.
-- Does NOT create new app tables or change product activation flags.
-- Products store object paths such as uploads/<uuid>.jpg in public.products.image_path.
BEGIN;
INSERT INTO storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
VALUES ('product-images','product-images',true,5242880,ARRAY['image/jpeg','image/png','image/webp'])
ON CONFLICT(id) DO UPDATE SET
  public=EXCLUDED.public,
  file_size_limit=EXCLUDED.file_size_limit,
  allowed_mime_types=EXCLUDED.allowed_mime_types;
-- Only authenticated owner may INSERT new product images, never anonymous users.
-- Requires private.is_owner() from 01_init.sql (already installed).
DROP POLICY IF EXISTS tulipa_owner_insert_product_images ON storage.objects;
CREATE POLICY tulipa_owner_insert_product_images
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
 bucket_id='product-images'
 AND (SELECT private.is_owner())
 AND (storage.foldername(name))[1]='uploads'
 AND lower(storage.extension(name)) IN ('jpg','jpeg','png','webp')
);
COMMIT;
-- Public bucket means anyone with a file URL can view that image.
-- No UPDATE/DELETE/SELECT listing grants; images for a public storefront only.
-- Do not upload private employee/customer documents or confidential content.
