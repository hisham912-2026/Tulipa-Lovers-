-- Tulipa Lovers v0.8: hosted Moyasar TEST invoice integration; run in Tulipa project only.
-- Do NOT apply to Hajj project. Must run AFTER v0.7 + checkout hotfix.
-- No production merchant credentials or real payments enabled by this migration.
BEGIN;
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_payment_method_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_payment_method_check CHECK (payment_method IN ('cash_on_delivery','moyasar_test'));
-- Protect electronic payment status from browser edits, including owners. Only trusted server with service role may update it.
REVOKE UPDATE(payment_status) ON public.orders FROM authenticated;

CREATE TABLE IF NOT EXISTS public.payment_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL UNIQUE REFERENCES public.orders(id) ON DELETE RESTRICT,
  provider text NOT NULL DEFAULT 'moyasar' CHECK(provider='moyasar'),
  invoice_id uuid UNIQUE,
  amount_halalas bigint NOT NULL CHECK(amount_halalas>=100),
  currency char(3) NOT NULL DEFAULT 'SAR' CHECK(currency='SAR'),
  state text NOT NULL DEFAULT 'creating' CHECK(state IN ('creating','initiated','test_paid','failed','review')),
  checkout_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.payment_invoices ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.payment_invoices FROM anon, authenticated;
GRANT SELECT ON public.payment_invoices TO authenticated;
CREATE POLICY payment_invoice_read ON public.payment_invoices FOR SELECT TO authenticated
 USING ((SELECT private.is_owner()) OR EXISTS (
   SELECT 1 FROM public.orders o WHERE o.id=order_id AND o.customer_id=(SELECT auth.uid())
 ));

-- Owners still may record money received in cash, but never manually confirm electronic payments.
CREATE OR REPLACE FUNCTION public.record_cash_payment(p_order_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_order public.orders%ROWTYPE;
BEGIN
 IF (SELECT auth.uid()) IS NULL OR NOT (SELECT private.is_owner()) THEN RAISE EXCEPTION 'Only owner can record cash payments'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=p_order_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Order not found'; END IF;
 IF v_order.payment_method<>'cash_on_delivery' THEN RAISE EXCEPTION 'Electronic payments must be verified with the provider'; END IF;
 IF v_order.status='cancelled' THEN RAISE EXCEPTION 'Cannot mark a cancelled order paid'; END IF;
 UPDATE public.orders SET payment_status='paid' WHERE id=p_order_id AND payment_status='unpaid';
 RETURN p_order_id;
END; $$;
REVOKE ALL ON FUNCTION public.record_cash_payment(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.record_cash_payment(uuid) TO authenticated;
COMMIT;
