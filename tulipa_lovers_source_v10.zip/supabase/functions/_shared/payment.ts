export const SUPABASE = Deno.env.get('SUPABASE_URL') || '';
const ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const SECRET = Deno.env.get('MOYASAR_TEST_SECRET_KEY') || '';
const ORIGIN = 'https://hisham912-2026.github.io';
const CHECKOUT_URL = 'https://hisham912-2026.github.io/Tulipa-Lovers-/#/orders';
export const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export const cors = {'Access-Control-Allow-Origin':ORIGIN,'Access-Control-Allow-Headers':'authorization, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
export function json(data: unknown, status=200, useCors=true): Response {
 return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store',...(useCors?cors:{})}});
}
export function assertConfigured(){
 if(!SUPABASE||!ROLE||!SECRET.startsWith('sk_test_'))throw new Error('Payment test backend not configured. Set only sk_test_ in Edge Function secrets.');
}
export async function userFromJwt(req: Request): Promise<{id:string}> {
 const token=(req.headers.get('Authorization')||'').match(/^Bearer\s+(.+)$/i)?.[1];
 if(!token)throw new Error('Login required');
 const r=await fetch(SUPABASE+'/auth/v1/user',{headers:{apikey:ROLE,Authorization:'Bearer '+token}});
 if(!r.ok)throw new Error('Session invalid. Sign in again.');
 const u=await r.json();if(!UUID.test(u?.id||''))throw new Error('Invalid session');
 return {id:u.id};
}
export async function db(path:string,method='GET',body?:unknown):Promise<any>{
 const r=await fetch(SUPABASE+'/rest/v1/'+path,{method,headers:{apikey:ROLE,Authorization:'Bearer '+ROLE,'Content-Type':'application/json',Prefer:'return=representation'},body:body===undefined?undefined:JSON.stringify(body)});
 const t=await r.text();let out:any;try{out=JSON.parse(t)}catch{out=t}
 if(!r.ok)throw new Error('Database rejected payment record ('+r.status+')');
 return out;
}
export async function moyasar(path:string,method='GET',body?:unknown):Promise<any>{
 const r=await fetch('https://api.moyasar.com/v1/'+path,{method,headers:{Authorization:'Basic '+btoa(SECRET+':'),'Content-Type':'application/json','Accept':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});
 const t=await r.text();let out:any;try{out=JSON.parse(t)}catch{out=t}
 if(!r.ok)throw new Error('Moyasar TEST rejected the request ('+r.status+')');
 return out;
}
export function amountHalalas(total:any):number{
 // Numeric from Postgres may be string; never take prices from client.
 const s=String(total);
 if(!/^\d{1,9}(\.\d{1,2})?$/.test(s))throw new Error('Invalid order amount');
 const [riyals,halalas='']=s.split('.'); const cents=Number(riyals)*100+Number(halalas.padEnd(2,'0'));
 if(!Number.isSafeInteger(cents)||cents<100)throw new Error('Minimum online payment amount is SAR 1');
 return cents;
}
export async function confirmedInvoice(rec:any):Promise<{paid:boolean,review:boolean,invoice:any}>{
 if(!UUID.test(rec.invoice_id||''))throw new Error('No payment invoice for this order');
 const invoice=await moyasar('invoices/'+encodeURIComponent(rec.invoice_id));
 if(invoice.id!==rec.invoice_id||invoice.currency!=='SAR'||Number(invoice.amount)!==Number(rec.amount_halalas))throw new Error('Payment amount or reference mismatch; manual review required');
 const orderId=String(invoice?.metadata?.order_id||'');
 if(orderId && orderId!==rec.order_id)throw new Error('Payment metadata mismatch');
 const paid=invoice.status==='paid';
 if(paid){
  const orders=await db('orders?id=eq.'+encodeURIComponent(rec.order_id)+'&select=id,status,payment_status,payment_method,total_sar');
  const order=orders?.[0];if(!order||order.payment_method!=='moyasar_test'||amountHalalas(order.total_sar)!==rec.amount_halalas)throw new Error('Order invalid or changed; reconcile payment manually');
  const review=order.status==='cancelled';
  await db('payment_invoices?id=eq.'+encodeURIComponent(rec.id),'PATCH',{state:review?'review':'test_paid',updated_at:new Date().toISOString()});
  // TEST NEVER changes orders.payment_status, awards points, or records real proceeds.
  return {paid:!review,review,invoice};
 }
 return {paid:false,review:false,invoice};
}
export const PAYMENT_ORIGIN=ORIGIN;
export const PAYMENT_CHECKOUT=CHECKOUT_URL;
