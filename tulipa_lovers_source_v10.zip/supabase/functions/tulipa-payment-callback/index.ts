import {assertConfigured,confirmedInvoice,db,json,UUID} from '../_shared/payment.ts';
// Public callback intentionally has verify_jwt=false: never trust POST fields.
// Independently fetch invoice from Moyasar with server-only sk_test and compare saved amount/order.
Deno.serve(async(req:Request)=>{
 if(req.method!=='POST')return json({error:'Method not allowed'},405,false);
 try{
  assertConfigured();
  const body=await req.json();
  const invoiceId=String(body?.id||body?.invoice_id||body?.data?.invoice_id||body?.data?.id||'');
  if(!UUID.test(invoiceId))return json({error:'Invalid invoice reference'},400,false);
  const records=await db('payment_invoices?invoice_id=eq.'+encodeURIComponent(invoiceId)+'&select=*');
  const rec=records?.[0];if(!rec)return json({error:'Unknown invoice'},404,false);
  const outcome=await confirmedInvoice(rec);
  return json({ok:true,paid:outcome.paid,review:outcome.review},200,false);
 }catch(e){return json({error:'Unable to verify payment'},400,false)}
});
