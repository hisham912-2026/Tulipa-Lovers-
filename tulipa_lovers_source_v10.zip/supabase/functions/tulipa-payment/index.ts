import {assertConfigured,amountHalalas,confirmedInvoice,cors,db,json,moyasar,PAYMENT_CHECKOUT,PAYMENT_ORIGIN,UUID,userFromJwt} from '../_shared/payment.ts';
Deno.serve(async (req:Request)=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(req.headers.get('Origin')&&req.headers.get('Origin')!==PAYMENT_ORIGIN)return json({error:'Origin not allowed'},403);
 try{
  assertConfigured();
  const user=await userFromJwt(req);
  const input=await req.json();const orderId=String(input?.order_id||'');
  if(!UUID.test(orderId))return json({error:'Invalid order ID'},400);
  const rows=await db('orders?id=eq.'+encodeURIComponent(orderId)+'&select=id,customer_id,status,payment_status,payment_method,total_sar');
  const o=rows?.[0];if(!o||o.customer_id!==user.id)return json({error:'Order not found'},404);
  if(o.payment_status==='paid')return json({status:'paid'});
  if(o.status==='cancelled'||o.status==='delivered')return json({error:'This order is not payable'},409);
  const amount=amountHalalas(o.total_sar);
  const records=await db('payment_invoices?order_id=eq.'+orderId+'&select=*');
  const current=records?.[0];
  if(input?.action==='verify'){
   if(!current?.invoice_id)return json({status:'unpaid'});
   const verification=await confirmedInvoice(current);
   return json({status:verification.paid?'test_paid':verification.review?'review':'unpaid'});
  }
  if(input?.action!=='create')return json({error:'Unknown payment action'},400);
  if(o.payment_method==='moyasar_test'&&current?.checkout_url){
   // Reuse the original provider invoice, never create a duplicate charge.
   const checked=await confirmedInvoice(current);
   if(checked.paid)return json({status:'test_paid'});
   if(checked.review)return json({status:'review'});
   if(checked.invoice.status==='initiated'||checked.invoice.status==='on_hold')return json({status:'initiated',url:current.checkout_url});
   return json({error:'Existing invoice expired or failed. Contact the store to resolve this order.'},409);
  }
  if(current)return json({error:'Payment preparation is already in progress, retry in a moment.'},409);
  if(o.payment_method!=='cash_on_delivery')return json({error:'Order payment method not eligible'},409);
  // Unique(order_id) ensures concurrent clicks cannot create multiple provider invoices.
  let reservation;
  try{
   const reserved=await db('payment_invoices','POST',{order_id:orderId,amount_halalas:amount,provider:'moyasar',state:'creating'});
   reservation=reserved?.[0];
  }catch{return json({error:'Payment setup already in progress. Please refresh your orders.'},409)}
  try{
   const urlBase=SUPABASE_URL();
   const invoice=await moyasar('invoices','POST',{
    amount,currency:'SAR',description:'Tulipa Lovers order '+orderId.slice(0,8),
    success_url:PAYMENT_CHECKOUT,back_url:PAYMENT_CHECKOUT,
    callback_url:urlBase+'/functions/v1/tulipa-payment-callback',
    metadata:{order_id:orderId}
   });
   if(!UUID.test(invoice?.id||'')||!/^https:\/\//.test(invoice?.url||'')||Number(invoice.amount)!==amount||invoice.currency!=='SAR')throw new Error('Provider returned an invalid invoice');
   await db('payment_invoices?id=eq.'+reservation.id,'PATCH',{invoice_id:invoice.id,checkout_url:invoice.url,state:'initiated',updated_at:new Date().toISOString()});
   await db('orders?id=eq.'+orderId,'PATCH',{payment_method:'moyasar_test'});
   return json({status:'initiated',url:invoice.url});
  }catch(err){
   // Preserve the reservation for manual reconciliation; do not issue a second invoice automatically.
   try{await db('payment_invoices?id=eq.'+reservation.id,'PATCH',{state:'review',updated_at:new Date().toISOString()});}catch{/* keep reservation */}
   return json({error:'Could not prepare payment. '+String((err as Error).message)},502);
  }
 }catch(e){return json({error:String((e as Error).message||e)},400)}
});
function SUPABASE_URL(){return (Deno.env.get('SUPABASE_URL')||'').replace(/\/$/,'')}
