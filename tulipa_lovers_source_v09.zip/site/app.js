import * as api from './api.js';
const $=id=>document.getElementById(id);
const categories={all:'الكل',bouquets:'بوكيهات',gifts:'هدايا',natural:'ورد طبيعي',imported:'ورد مستورد',occasions:'مناسبات',wrapping:'تغليف'};
const icons={all:'🌷',bouquets:'💐',gifts:'🎁',natural:'🌹',imported:'🌼',occasions:'🎉',wrapping:'🎀'};
const DEMO=[
{id:'4a2cdaf0-5ee4-49cc-a99f-000000000001',sku:'TL-001',title_ar:'بوكيه توليبا كلاسيك',description_ar:'توليب أبيض وتغليف أزرق فاخر',category:'bouquets',kind:'fixed',price_sar:249,stock_qty:10,image_path:'bouquet_white.jpg',active:true,featured:true},
{id:'4a2cdaf0-5ee4-49cc-a99f-000000000002',sku:'TL-002',title_ar:'بوكيه لمسة ورد',description_ar:'ورود وردية ناعمة بتنسيق أنيق',category:'bouquets',kind:'fixed',price_sar:299,stock_qty:12,image_path:'bouquet_pink.jpg',active:true,featured:true},
{id:'4a2cdaf0-5ee4-49cc-a99f-000000000003',sku:'TL-003',title_ar:'تنسيق الفخامة البيضاء',description_ar:'ورد أبيض داخل صندوق أنيق',category:'gifts',kind:'fixed',price_sar:349,stock_qty:4,image_path:'bouquet_box.jpg',active:true,featured:false},
{id:'4a2cdaf0-5ee4-49cc-a99f-000000000004',sku:'TL-004',title_ar:'باقة توليبا وهدية',description_ar:'تجهيز ورد وهدية بإطلالة وردية',category:'gifts',kind:'fixed',price_sar:329,stock_qty:6,image_path:'bouquet_gift.jpg',active:true,featured:false},
{id:'4a2cdaf0-5ee4-49cc-a99f-000000000005',sku:'TL-CUSTOM',title_ar:'صمّم بوكيهك',description_ar:'إنشاء تنسيق حسب اختيارك — يحتاج تأكيد',category:'bouquets',kind:'custom',price_sar:0,stock_qty:0,image_path:'hero_bouquet.jpg',active:true,featured:true},
{id:'demo06',title_ar:'بوكيه لمسة رومانسية',description_ar:'ورود وردية ومزيج ألوان',category:'natural',kind:'fixed',price_sar:279,stock_qty:8,image_path:'bouquet_rose.jpg',active:true},
{id:'demo07',title_ar:'بوكيه الورود البنفسجية',description_ar:'تنسيق احتفالي لافت',category:'imported',kind:'fixed',price_sar:319,stock_qty:8,image_path:'bouquet_lilac.jpg',active:true},
{id:'demo08',title_ar:'باقة الزهور المختارة',description_ar:'ورود مختلفة بألوان لطيفة',category:'occasions',kind:'fixed',price_sar:269,stock_qty:8,image_path:'bouquet_mix.jpg',active:true}
];
const STATE={page:'home',products:[],category:'all',query:'',productId:null,cart:read('tulipa.cart',[]),fav:read('tulipa.fav',[]),authMode:'signin',authMessage:'',authEmail:'',isPasswordRecovery:false,profile:null,orders:[],ledger:[],events:[],error:'',adminTab:'orders',notifications:[],notificationError:'',notificationsLoaded:false,design:{flower:'rose',stems:15,wrap:'luxury',card:true},pointsToRedeem:0,deliveryAreas:[],selectedDeliveryArea:'',deliveryError:''};
function read(k,f){try{return JSON.parse(localStorage.getItem(k))??f}catch{return f}}
function escapeHTML(x){return String(x??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
const esc=escapeHTML;
const sar=n=>`${Number(n||0).toFixed(2).replace(/\.00$/,'')} ر.س`;
const img=p=>esc(api.productImageUrl(p?.image_path));
function saveCart(){localStorage.setItem('tulipa.cart',JSON.stringify(STATE.cart))}
function isOwner(){return STATE.profile?.role==='owner'}
const unreadCount=()=>STATE.notifications.filter(n=>!n.read_at).length;
function toast(text){const t=document.createElement('div');t.className='toast';t.textContent=text;$('toasts').appendChild(t);setTimeout(()=>t.remove(),4800)}
function eMsg(e){toast(e?.message||String(e))}
function go(page){STATE.page=page;window.location.hash='#/'+page;render();window.scrollTo({top:0,behavior:'instant'})}
function find(id){return STATE.products.find(p=>p.id===id)}
const configuredNotice=()=>api.online?'':`<div class="notice warn"><strong>وضع المعاينة:</strong> المتجر غير مرتبط بعد بقاعدة بيانات توليبا المستقلة. المنتجات والأسعار هنا توضيحية، ولا يمكن إرسال طلبات حقيقية قبل إعداد Supabase.</div>`;
function nav(){const links=[['home','⌂','الرئيسية'],['shop','▦','الأقسام'],['design','✿','صمّم'],['orders','▤','الطلبات'],['account','♙','حسابي']];return `<nav class="nav" aria-label="التنقل الرئيسي">${links.map(([key,i,t])=>`<button data-go="${key}" class="${STATE.page===key?'active':''}" aria-label="${t}"><span>${i}</span>${t}</button>`).join('')}</nav>`}
function header(){let count=STATE.cart.reduce((a,c)=>a+c.quantity,0);return `<header><div class="header-inner"><button class="location" style="border:0" data-go="home">📍 الطائف</button><div class="brand"><div class="brand-mark">TL</div><div class="brand-copy"><strong>Tulipa Lovers</strong><small>لنجعل من هديتك ذكرى لا تُنسى</small></div></div><div class="top-actions">${isOwner()?`<button class="icon-btn notify-bell" data-open-notifications aria-label="إشعارات الطلبات${unreadCount()?'، '+unreadCount()+' غير مقروءة':''}">🔔${unreadCount()?`<span class="notif-badge">${unreadCount()>=100?'99+':unreadCount()}</span>`:''}</button>`:''}<button class="icon-btn" data-go="shop" aria-label="بحث">⌕</button><button class="icon-btn" data-go="cart" aria-label="السلة">🛒${count?' '+count:''}</button></div></div></header>`}
function card(p){return `<article class="product"><button class="photo" data-product="${esc(p.id)}" aria-label="عرض ${esc(p.title_ar)}"><img src="${img(p)}" alt="${esc(p.title_ar)}" loading="lazy"></button><div class="product-body"><h3>${esc(p.title_ar)}</h3><p>${esc(p.description_ar)}</p>${p.kind==='custom'?'<span class="badge pink">حسب الطلب</span>':`<div class="product-footer"><strong class="price">${sar(p.price_sar)}</strong><button class="icon-btn" data-fav="${esc(p.id)}" aria-label="المفضلة">${STATE.fav.includes(p.id)?'♥':'♡'}</button></div>`}<button class="btn full small" data-${p.kind==='custom'?'go="design"':'product="'+esc(p.id)+'"'}>${p.kind==='custom'?'صمّم الآن':'اختر التفاصيل'}</button></div></article>`}
function cats(){return `<div class="category-row">${Object.entries(categories).filter(([k])=>k!=='all').map(([k,n])=>`<button data-cat="${k}" class="cat ${STATE.category===k?'active':''}"><span class="emoji">${icons[k]}</span>${n}</button>`).join('')}</div>`}
function home(){const featured=STATE.products.filter(p=>p.active&&p.featured).slice(0,4);return `${configuredNotice()}<section class="hero"><div class="hero-copy"><div class="eyebrow">Tulipa Lovers · الطائف</div><h1>لنجعل من هديتك ذكرى لا تُنسى</h1><p>بوكيهات وهدايا تعبر عن أجمل المشاعر</p><button class="btn" data-go="shop">ابدأ التسوق ←</button></div><img src="images/hero_bouquet.jpg" alt="باقة زهور توليبا" /></section><section class="section"><div class="section-title"><h2>تسوق حسب المناسبة</h2><button class="btn secondary small" data-go="shop">عرض الكل</button></div>${cats()}</section><section class="section"><div class="section-title"><h2>اختيارات توليبا</h2><span class="badge pink">لأجمل الإهداءات</span></div>${featured.length?`<div class="grid">${featured.map(card).join('')}</div>`:'<div class="empty">ستظهر المنتجات عندما يقوم المالك بنشرها من لوحة الإدارة.</div>'}</section><div class="banner"><div><h2>🌷 صمّم بوكيهك بنفسك</h2><p>اختر نوع الورد وعدده والتغليف، واطلب مراجعة تصميمك</p></div><button class="btn" data-go="design">ابدأ التصميم</button></div><section class="section"><div class="section-title"><h2>من أعمالنا</h2><span class="badge">صور توضيحية — تُستبدل بصور المحل الأصلية</span></div><div class="grid">${['bouquet_mix.jpg','bouquet_lilac.jpg','bouquet_white.jpg','bouquet_gift.jpg'].map(n=>`<div class="product"><img src="images/${n}" alt="تنسيق ورود توضيحي" style="width:100%;height:160px"></div>`).join('')}</div></section><div class="banner"><div><h2>🎁 نقاط الولاء</h2><p>اجمع نقاطًا بعد تسليم الطلب وسداد قيمته واستبدلها بمكافآت</p></div><button class="btn secondary" data-go="account">اعرف أكثر</button></div>`}
function shop(){let products=STATE.products.filter(p=>p.active&&(STATE.category==='all'||p.category===STATE.category));if(STATE.query)products=products.filter(p=>(p.title_ar+' '+p.description_ar).includes(STATE.query));return `${configuredNotice()}<h1 class="page-title">المتجر 🌷</h1><p class="subtitle">بوكيهات وهدايا وتنسيقات مناسبة لذوقك — توصيل داخل الطائف</p><form id="searchForm" class="search-row"><input name="query" class="field" placeholder="ابحث عن بوكيه أو هدية..." value="${esc(STATE.query)}"/><button class="btn" type="submit">بحث</button></form>${cats()}<section class="section"><div class="section-title"><h2>${categories[STATE.category]}</h2><span class="badge">${products.length} منتجات</span></div>${products.length?`<div class="grid">${products.map(card).join('')}</div>`:'<p class="empty">لا توجد منتجات منشورة بهذا التصنيف.</p>'}</section>`}
function product(){const p=find(STATE.productId);if(!p)return `<div class="empty">المنتج غير متاح. <button data-go="shop" class="btn">الرجوع للمتجر</button></div>`;if(p.kind==='custom')return design();return `<div class="cols2"><div><img class="detail-hero" src="${img(p)}" alt="${esc(p.title_ar)}"></div><div class="product-info"><span class="badge">🌷 تصميم توليبا</span><h1 class="page-title">${esc(p.title_ar)}</h1><p>${esc(p.description_ar)}</p><strong class="price">${sar(p.price_sar)}</strong><span class="notice">📍 التوصيل داخل الطائف · يحدد الموعد قبل تأكيد الطلب</span><p>المخزون المتاح حاليًا: <strong>${p.stock_qty}</strong></p><p class="subtitle">المنتجات الثابتة بهذا الإصدار تُطلب كما هي. للتغييرات الخاصة استخدم مصمم البوكيه، وسيتم مراجعة الطلب من المحل.</p><button class="btn" data-add="${esc(p.id)}" ${p.stock_qty<1?'disabled':''}>${p.stock_qty<1?'غير متوفر حاليًا':'أضف إلى السلة'}</button><button class="btn outline" data-go="design">أريد تصميمًا مختلفًا</button></div></div>`}
function designPrice(){const d=STATE.design;return d.stems*({rose:12,tulip:17,lily:22}[d.flower]||12)+({classic:15,luxury:30,box:45}[d.wrap]||15)+(d.card?10:0)}
function choices(key,options){return `<div class="choices">${options.map(([v,label])=>`<button class="chip ${String(STATE.design[key])===String(v)?'selected':''}" data-design-key="${key}" data-design-value="${v}">${label}</button>`).join('')}</div>`}
function design(){const p=STATE.products.find(p=>p.kind==='custom'&&p.active);return `<h1 class="page-title">صمّم بوكيهك 🌷</h1><p class="subtitle">اختار المكونات ثم أرسل الطلب للمحل للمراجعة والتأكيد</p><div class="cols2"><img class="detail-hero" src="images/hero_bouquet.jpg" alt="صورة توضيحية لتنسيق مخصص"><div class="card stack"><h2>1. نوع الزهور</h2>${choices('flower',[['rose','ورد جوري'],['tulip','توليب'],['lily','ليليوم']])}<h2>2. عدد السيقان</h2>${choices('stems',[[10,'10'],[15,'15'],[25,'25'],[50,'50']])}<h2>3. التغليف</h2>${choices('wrap',[['classic','كلاسيكي'],['luxury','فاخر'],['box','صندوق']])}<h2>4. بطاقة الإهداء</h2>${choices('card',[[true,'مع بطاقة'],[false,'دون بطاقة']])}<div class="total-line big"><span>السعر التقديري</span><strong>${sar(designPrice())}</strong></div><div class="notice">هذا تقدير يُعاد حسابه على الخادم. تصميم البوكيه مبدئي، ويحتاج موافقة المحل وتأكيد توفر الزهور.</div><button class="btn full" data-add-design ${!p?'disabled':''}>${p?'أضف التصميم للسلة':'التصميم غير منشور حاليًا'}</button></div></div>`}
function lineKey(c){return `${c.product_id}|${JSON.stringify(c.customization||{})}`}
function add(id){const p=find(id);if(!p||!p.active)return toast('المنتج غير متاح');if(p.kind==='custom')return go('design');if(p.stock_qty<1)return toast('نفدت الكمية');const item={product_id:p.id,quantity:1,customization:{},name:p.title_ar,price:Number(p.price_sar),image_path:p.image_path,kind:p.kind};let existing=STATE.cart.find(c=>lineKey(c)===lineKey(item));if(existing){if(existing.quantity>=Math.min(10,p.stock_qty))return toast('وصلت للحد المتاح');existing.quantity++}else STATE.cart.push(item);saveCart();toast('أُضيف المنتج إلى السلة');render()}
function addDesign(){const p=STATE.products.find(p=>p.kind==='custom'&&p.active);if(!p)return;const item={product_id:p.id,quantity:1,customization:{...STATE.design},name:p.title_ar,price:designPrice(),image_path:p.image_path,kind:'custom'};const current=STATE.cart.find(x=>lineKey(x)===lineKey(item));if(current)current.quantity=Math.min(10,current.quantity+1);else STATE.cart.push(item);saveCart();go('cart')}
function cartTotal(){return STATE.cart.reduce((s,c)=>s+c.price*c.quantity,0)}
function points(){return STATE.ledger.reduce((s,l)=>s+l.points_delta,0)}
function enabledDeliveryAreas(){return STATE.deliveryAreas.filter(a=>a.active===true)}
function chosenDeliveryArea(){return enabledDeliveryAreas().find(a=>a.id===STATE.selectedDeliveryArea)||null}
function deliveryFee(){const area=chosenDeliveryArea();return area===null?null:Number(area.fee_sar)}
function displayedTotal(){const fee=deliveryFee();return fee===null?null:cartTotal()+fee-STATE.pointsToRedeem/20}
function updateDeliveryTotal(){
 const fee=deliveryFee(),d=$('deliveryFee'),t=$('summaryGrand'),label=$('deliveryRegionNote');
 if(d)d.textContent=fee===null?'اختر الحي أولًا':sar(fee);
 if(t)t.textContent=fee===null?'يظهر الإجمالي بعد اختيار الحي':sar(displayedTotal());
 if(label)label.textContent=fee===null?'اختر حيًا من القائمة لمعرفة رسوم التوصيل.':`تكلفة التوصيل إلى ${chosenDeliveryArea().name_ar}: ${sar(fee)}.`;
}

function cart(){
 const subtotal=cartTotal();
 const allowed=Math.min(Math.floor(points()/100)*100,Math.floor(subtotal*.2/5)*100);
 const used=Math.min(STATE.pointsToRedeem,allowed);STATE.pointsToRedeem=used;
 const discount=used/20, fee=deliveryFee(),grand=fee===null?null:subtotal+fee-discount;
 const areas=enabledDeliveryAreas();
 return `${configuredNotice()}<h1 class="page-title">سلة التسوق 🛒</h1><div class="cols2">
 <div class="card">${STATE.cart.length?STATE.cart.map((c,i)=>`<div class="basket-line"><img src="${esc(api.productImageUrl(c.image_path))}" alt="${esc(c.name)}"><div><strong>${esc(c.name)}</strong>${c.kind==='custom'?'<div class="badge pink">مراجعة من المحل</div>':''}<p class="subtitle">${sar(c.price)} للقطعة</p></div><div class="qty"><button data-qty="${i}" data-delta="-1" aria-label="إنقاص">−</button><span>${c.quantity}</span><button data-qty="${i}" data-delta="1" aria-label="زيادة">+</button><button data-remove="${i}" aria-label="حذف">×</button></div></div>`).join(''):'<div class="empty">السلة فارغة حاليًا. <button class="btn" data-go="shop">تسوق الآن</button></div>'}</div>
 <div class="stack"><div class="card"><h2>ملخص التكلفة</h2>
 <div class="total-line"><span>المنتجات</span><strong>${sar(subtotal)}</strong></div>
 <div class="total-line"><span>رسوم التوصيل حسب الحي</span><strong id="deliveryFee">${fee===null?'اختر الحي أولًا':sar(fee)}</strong></div>
 <div class="total-line"><span>خصم الولاء</span><strong id="summaryDiscount">− ${sar(discount)}</strong></div>
 <div class="total-line big"><span>الإجمالي التقديري</span><strong id="summaryGrand">${grand===null?'يظهر الإجمالي بعد اختيار الحي':sar(grand)}</strong></div>
 <div class="form-group"><label>استبدال نقاط الولاء (الرصيد: ${points()} نقطة)</label><select class="select" id="redeemPoints">${Array.from({length:Math.floor(allowed/100)+1},(_,i)=>i*100).map(n=>`<option value="${n}" ${used===n?'selected':''}>${n} نقطة${n?' = '+sar(n/20):''}</option>`).join('')}</select></div>
 </div><div class="card"><h2>بيانات التوصيل</h2>
 <p class="subtitle">التوصيل داخل الأحياء التي يفعّلها مالك المتجر فقط. رسوم التوصيل يُعاد احتسابها في Supabase عند إرسال الطلب.</p>
 ${STATE.deliveryError?`<div class="notice warn">${esc(STATE.deliveryError)}</div>`:''}${!areas.length?'<div class="notice warn">لا توجد أحياء متاحة للتوصيل حاليًا. يرجى التواصل مع المحل حتى يُفعّل المالك مناطق التوصيل ورسومها.</div>':''}
 <form id="checkoutForm" class="stack">
 <div class="form-group"><label>اسم المستلم</label><input required minlength="2" maxlength="120" class="field" name="recipient_name" autocomplete="name"></div>
 <div class="form-group"><label>جوال المستلم (05xxxxxxxx)</label><input required class="field" name="recipient_phone" pattern="0?5[0-9]{8}|\\+9665[0-9]{8}" inputmode="tel" placeholder="05xxxxxxxx"></div>
 <div class="form-group"><label for="deliveryAreaSelect">الحي أو منطقة التوصيل داخل الطائف</label><select required class="select" name="delivery_area_id" id="deliveryAreaSelect"><option value="">— اختر الحي —</option>${areas.map(a=>`<option value="${esc(a.id)}" ${a.id===STATE.selectedDeliveryArea?'selected':''}>${esc(a.name_ar)} — ${sar(a.fee_sar)}</option>`).join('')}</select><p class="subtitle" id="deliveryRegionNote">${fee===null?'اختر حيًا من القائمة لمعرفة رسوم التوصيل.':`تكلفة التوصيل إلى ${esc(chosenDeliveryArea().name_ar)}: ${sar(fee)}.`}</p></div>
 <div class="form-group"><label>العنوان التفصيلي</label><input required minlength="5" maxlength="300" class="field" name="address"></div>
 <div class="form-group"><label>موعد التوصيل (بعد ساعتين على الأقل)</label><input required type="datetime-local" class="field" name="delivery_at"></div>
 <div class="form-group"><label>ملاحظات</label><textarea maxlength="500" class="textarea" name="note"></textarea></div>
 <div class="notice">وسيلة الدفع الحالية: <strong>عند الاستلام</strong>. ${api.paymentTestEnabled?'يمكنك بعد إرسال الطلب اختيار الدفع التجريبي من صفحة «طلباتي»؛ لا يُخصم مال حقيقي.':'الدفع الإلكتروني غير مفعّل حاليًا؛ لا يُجرى تحصيل إلكتروني.'} السعر النهائي يُحدده الخادم.</div>
 <button class="btn full" type="submit" ${STATE.cart.length&&api.online&&areas.length?'':'disabled'}>${api.online?(areas.length?'إرسال الطلب للمحل':'التوصيل غير متاح حتى تفعيل الأحياء'):'يلزم ربط قاعدة البيانات لإرسال الطلب'}</button></form></div></div></div>`;
}

function login(){
 const message=STATE.authMessage?`<div class="notice">${esc(STATE.authMessage)}</div>`:'';
 const tabs=`<div class="choices"><button type="button" class="chip ${STATE.authMode==='signin'?'selected':''}" data-auth-mode="signin">تسجيل الدخول</button><button type="button" class="chip ${STATE.authMode==='signup'?'selected':''}" data-auth-mode="signup">حساب جديد</button></div>`;
 const emailField=`<label>البريد الإلكتروني</label><input class="field" type="email" name="email" required autocomplete="email" placeholder="name@example.com" value="${esc(STATE.authEmail)}">`;
 if(STATE.authMode==='forgot')return `<div class="card stack" style="max-width:520px"><h2>استعادة كلمة المرور</h2><p class="subtitle">سنرسل رابط إعادة تعيين كلمة المرور إلى بريدك إذا كانت الخدمة متاحة.</p>${message}<form id="requestResetForm" class="stack">${emailField}<button class="btn" ${api.online?'':'disabled'}>إرسال رابط الاستعادة</button></form><button class="btn outline" data-auth-mode="signin">العودة لتسجيل الدخول</button></div>`;
 if(STATE.authMode==='signup')return `<div class="card stack" style="max-width:520px"><h2>إنشاء حساب توليبا</h2><p class="subtitle">التسجيل بالبريد الإلكتروني وكلمة المرور. يلزم تأكيد البريد قبل أول دخول عند تفعيل تأكيد البريد في Supabase. لا تُرسل رسائل SMS.</p>${message}${tabs}<form id="emailSignUpForm" class="stack"><label>الاسم الكامل</label><input class="field" name="full_name" required minlength="2" maxlength="120" autocomplete="name" placeholder="الاسم الكامل">${emailField}<label>كلمة المرور (8 أحرف على الأقل)</label><input class="field" type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required><label>تأكيد كلمة المرور</label><input class="field" type="password" name="confirm_password" minlength="8" maxlength="72" autocomplete="new-password" required><button class="btn" ${api.online?'':'disabled'}>إنشاء الحساب</button></form></div>`;
 return `<div class="card stack" style="max-width:520px"><h2>الدخول إلى حسابي</h2><p class="subtitle">دخول آمن بالبريد الإلكتروني وكلمة المرور. رقم الجوال مطلوب للتوصيل فقط ولن يُعتبر موثّقًا.</p>${message}${tabs}<form id="emailSignInForm" class="stack">${emailField}<label>كلمة المرور</label><input class="field" type="password" name="password" autocomplete="current-password" required><button class="btn" ${api.online?'':'disabled'}>دخول</button></form><button class="btn outline" data-auth-mode="forgot">نسيت كلمة المرور؟</button></div>`;
}
function account(){if(STATE.isPasswordRecovery && api.currentUser())return `<h1 class="page-title">تعيين كلمة مرور جديدة</h1><div class="card stack" style="max-width:520px"><form id="resetPasswordForm" class="stack"><label>كلمة المرور الجديدة</label><input class="field" type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required><label>تأكيد كلمة المرور</label><input class="field" type="password" name="confirm_password" minlength="8" maxlength="72" autocomplete="new-password" required><button class="btn">حفظ كلمة المرور</button></form></div>`;return `${configuredNotice()}<h1 class="page-title">حسابي</h1>${!api.currentUser()?login():`<div class="cols2"><div class="card stack"><h2>بيانات الحساب</h2><span class="badge">${isOwner()?'حساب المالك':'حساب عميل'}</span><form id="profileForm" class="stack"><label>الاسم</label><input class="field" required name="full_name" minlength="2" maxlength="120" value="${esc(STATE.profile?.full_name||'')}"><p class="subtitle">رقم الجوال غير موثّق في هذه المرحلة. يُطلب رقم هاتف المستلم عند إتمام الطلب.</p><button class="btn">حفظ الاسم</button></form><form id="emailForm" class="stack"><label>البريد الإلكتروني (يُرسل له رابط تأكيد)</label><input name="email" class="field" required type="email" value="${esc(STATE.profile?.email||'')}"><button class="btn secondary">إضافة / تحديث البريد</button></form><button class="btn outline" data-logout>تسجيل الخروج</button></div><div class="card stack"><h2>🎁 نقاط توليبا</h2><strong class="price">${points()} نقطة</strong><p>تُكتسب نقطة لكل ريال من سعر المنتجات بعد أن يثبت المالك استلام المبلغ وتسليم الطلب.</p><p class="subtitle">كل 100 نقطة = خصم 5 ريالات، بحد أقصى 20% من المنتجات.</p><button class="btn secondary" data-go="orders">عرض طلباتي</button>${isOwner()?'<button class="btn" data-go="admin">لوحة تحكم المالك</button>':''}</div></div>`}`}
function orders(){return `${configuredNotice()}<h1 class="page-title">طلباتي</h1>${!api.currentUser()?login():!STATE.orders.length?'<div class="empty">لم تُسجل طلبات بعد</div>':`<div class="stack">${STATE.orders.map(o=>`<div class="card stack"><div class="row"><strong>طلب #${esc(o.id.slice(0,8))}</strong><span class="status-pill">${esc(o.status)}</span></div><div>${new Date(o.created_at).toLocaleString('ar-SA')} · ${sar(o.total_sar)}</div><div>📍 ${esc(o.district)} — ${esc(o.city)}</div><div class="subtitle">المنتجات: ${sar(o.subtotal_sar)} + رسوم التوصيل: ${sar(o.delivery_sar)}</div><div class="subtitle">${(o.order_items||[]).map(i=>esc(i.product_title)+' × '+i.quantity).join('، ')}</div><span class="badge">${o.payment_status==='paid'?'مدفوع':o.payment_method==='moyasar_test'?'اختبار دفع إلكتروني — لم يُحَصَّل مبلغ حقيقي':'غير مدفوع — عند الاستلام'}</span>${api.paymentTestEnabled && o.payment_status!=='paid' && o.status!=='cancelled' && o.status!=='delivered'?`<div class="choices"><button class="btn small" data-online-pay="${esc(o.id)}">${o.payment_method==='moyasar_test'?'متابعة الدفع التجريبي':'ادفع إلكترونيًا (اختبار فقط)'}</button><button class="btn secondary small" data-verify-pay="${esc(o.id)}">التحقق من حالة الدفع</button></div>`:''}</div>`).join('')}</div>`}`}
function events(){return `${configuredNotice()}<h1 class="page-title">تجهيز المناسبات 🎉</h1><p class="subtitle">الخطوبة وعقد القران والتخرج والافتتاحات وتجهيز الحفلات في الطائف</p>${!api.currentUser()?login():`<div class="card" style="max-width:680px"><form id="eventForm" class="stack"><div class="form-group"><label>نوع المناسبة</label><select name="event_type" class="select"><option>عقد قران</option><option>خطوبة</option><option>زواج</option><option>حفل تخرج</option><option>افتتاح</option><option>مناسبة أخرى</option></select></div><div class="form-group"><label>تاريخ المناسبة</label><input type="date" required name="event_date" class="field"></div><div class="form-group"><label>الحي / الموقع داخل الطائف</label><input required minlength="2" name="district" class="field"></div><div class="form-group"><label>الميزانية المتوقعة (ريال)</label><input type="number" min="0" name="budget" class="field"></div><div class="form-group"><label>وصف المطلوب</label><textarea name="details" required minlength="10" maxlength="1000" class="textarea"></textarea></div><button class="btn">إرسال طلب عرض السعر</button></form></div>`}`}
const statusAr={pending:'بانتظار الموافقة',pending_review:'تصميم قيد المراجعة',confirmed:'مؤكد',preparing:'جارٍ التجهيز',out_for_delivery:'خرج للتوصيل',delivered:'تم التسليم',cancelled:'ملغي'};
function admin(){if(!isOwner())return `<h1>ليست لديك صلاحية لوحة الإدارة</h1>`;const tabs=[['orders','الطلبات'],['notifications',`🔔 الإشعارات${unreadCount()?' ('+unreadCount()+')':''}`],['products','المنتجات'],['customers','العملاء'],['events','المناسبات'],['delivery','التوصيل']];let html=`<h1 class="page-title">لوحة إدارة توليبا 🔐</h1><div class="notice">البيانات هنا حقيقية من قاعدة البيانات مع حماية صلاحيات المالك. جميع عمليات التسليم والدفع تُسجل بعد تحقق الموظف.</div><div class="tabs">${tabs.map(([key,name])=>`<button data-admin-tab="${key}" class="${STATE.adminTab===key?'selected':''}">${name}</button>`).join('')}</div>`;
if(STATE.adminTab==='notifications')html+=`<section class="card stack" aria-label="إشعارات الطلبات"><div class="row"><div><h2>🔔 إشعارات الطلبات الجديدة</h2><p class="subtitle">تُحدَّث تلقائيًا كل 30 ثانية أثناء فتح لوحة المالك. لا تُرسل رسائل أو إشعارات خارج المتجر.</p></div><button class="btn secondary small" data-refresh-notifications>تحديث الآن</button></div>${STATE.notificationError?`<div class="notice warn" role="alert">${esc(STATE.notificationError)}</div>`:''}<div class="row"><strong>${unreadCount()} غير مقروءة</strong><button class="btn small secondary" data-mark-all-notifications ${!unreadCount()?'disabled':''}>تعليم الكل كمقروء</button></div>${!STATE.notifications.length?'<div class="empty">لا توجد إشعارات طلبات جديدة بعد تفعيل هذه الميزة.</div>':`<div class="stack">${STATE.notifications.map(n=>{const order=STATE.orders.find(o=>o.id===n.order_id);return `<article class="notification-item ${n.read_at?'read':'unread'}"><div class="row"><strong>${n.read_at?'تمت القراءة':'● جديد'} — طلب #${esc(n.order_id.slice(0,8))}</strong><small>${new Date(n.created_at).toLocaleString('ar-SA')}</small></div><p>${order?`${esc(order.district)} · ${sar(order.total_sar)} · ${statusAr[order.status]||esc(order.status)}`:'اطّلع على بيانات الطلب من تبويب الطلبات'}</p><div class="choices"><button class="btn small" data-notification-order="${esc(n.order_id)}" data-notification-id="${esc(n.id)}">عرض الطلب</button>${n.read_at?'':`<button class="btn secondary small" data-notification-read="${esc(n.id)}">تعليم كمقروء</button>`}</div></article>`}).join('')}</div>`}<p class="subtitle">تُعرض أحدث 100 إشعار. الإشعارات الأقدم والطلبات السابقة متاحة من سجل الطلبات.</p></section>`;
if(STATE.adminTab==='orders')html+=`${unreadCount()?`<div class="notice"><button class="btn small secondary" data-admin-tab="notifications">🔔 يوجد ${unreadCount()} طلب جديد غير مقروء — عرض الإشعارات</button></div>`:''}<div class="stack">${!STATE.orders.length?'<div class="empty">لا توجد طلبات</div>':STATE.orders.map(o=>`<div class="card stack" id="order-${esc(o.id)}"><div class="row"><strong>${esc(o.id.slice(0,8))} — ${sar(o.total_sar)}</strong><span class="badge">${statusAr[o.status]||esc(o.status)}</span></div><div>${esc(o.recipient_name)} · ${esc(o.recipient_phone)} · ${esc(o.district)} / ${esc(o.address_text)}</div><div class="subtitle">سعر المنتجات: ${sar(o.subtotal_sar)} · التوصيل: ${sar(o.delivery_sar)}</div><div class="subtitle">${(o.order_items||[]).map(i=>esc(i.product_title)+' × '+i.quantity).join('، ')}</div><div>وسيلة الدفع: ${o.payment_method==='moyasar_test'?'ميسّر (اختبار دون تحصيل)':'عند الاستلام'} — ${o.payment_status==='paid'?'تم تأكيد التحصيل':'لم يؤكد التحصيل'}</div><div class="choices">${[['confirmed','تأكيد'],['preparing','تجهيز'],['out_for_delivery','توصيل'],['delivered','تم التسليم'],['cancelled','إلغاء']].map(([v,n])=>`<button class="btn secondary small" data-admin-status="${v}" data-order="${esc(o.id)}">${n}</button>`).join('')}<button class="btn small" data-admin-paid="${esc(o.id)}" ${o.payment_status==='paid'||o.payment_method!=='cash_on_delivery'?'disabled':''}>تأكيد استلام النقد</button></div></div>`).join('')}</div>`;
if(STATE.adminTab==='products')html+=`<div class="card stack"><h2>المنتجات والأسعار والمخزون</h2><div class="tablewrap"><table class="table"><tr><th>المنتج</th><th>السعر</th><th>الكمية</th><th>منشور</th><th>إدارة</th></tr>${STATE.products.map(p=>`<tr><td>${esc(p.title_ar)}</td><td>${sar(p.price_sar)}</td><td>${p.stock_qty}</td><td>${p.active?'نعم':'لا'}</td><td><button class="btn secondary small" data-edit-product="${esc(p.id)}">تعديل</button></td></tr>`).join('')}</table></div><h3>إنشاء / تعديل منتج</h3><form id="productForm" class="stack"><input type="hidden" name="id" id="productId"><input name="sku" class="field" required placeholder="رمز المنتج SKU"><input name="title_ar" class="field" required placeholder="اسم المنتج"><textarea name="description_ar" class="textarea" placeholder="الوصف"></textarea><select name="category" class="select">${Object.entries(categories).filter(([k])=>k!=='all').map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select><select name="kind" class="select"><option value="fixed">منتج جاهز</option><option value="custom">تصميم مخصص</option></select><label>السعر بالريال<input name="price_sar" type="number" step="0.01" min="0" class="field" required></label><label>الكمية المتاحة<input name="stock_qty" type="number" min="0" class="field" required></label><label>صورة المنتج الحالية<select class="select" name="image_path" id="existingProductImage">${[...new Set([...STATE.products.map(p=>p.image_path).filter(Boolean),'bouquet_white.jpg','bouquet_pink.jpg','bouquet_box.jpg','bouquet_gift.jpg','bouquet_mix.jpg','bouquet_rose.jpg','bouquet_lilac.jpg','hero_bouquet.jpg'])].map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select></label><label>ارفع صورة جديدة من جهازك (JPG / PNG / WebP، حتى 5 ميجابايت)<input name="new_image" id="newProductImage" class="field" type="file" accept="image/jpeg,image/png,image/webp"></label><div class="product-image-preview"><img id="productImagePreview" src="${esc(api.productImageUrl('bouquet_rose.jpg'))}" alt="معاينة صورة المنتج"><span id="productImageStatus" class="rtl-help">اختيار صورة جديدة يرفعها عند الضغط على حفظ المنتج. لن يُنشر المنتج تلقائيًا.</span></div><label><input type="checkbox" name="active"> منشور للبيع (بعد اعتماد السعر والصورة والمخزون)</label><label><input type="checkbox" name="featured"> منتج مميز</label><p id="productSaveStatus" class="notice warn" role="alert" hidden></p><button type="submit" class="btn">حفظ المنتج</button></form></div>`;
if(STATE.adminTab==='delivery')html+=`<div class="card stack"><h2>أحياء ومناطق التوصيل — الطائف</h2>
 ${STATE.deliveryError?`<div class="notice warn">${esc(STATE.deliveryError)}</div>`:''}<div class="notice warn">لا تُنشَر رسوم توصيل افتراضية. أضف كل حي والسعر المعتمد من المحل ثم فعّل إتاحته للعملاء. تعطيل الحي يمنع الطلبات الجديدة إليه ولا يغيّر رسوم الطلبات السابقة.</div>
 <div class="tablewrap"><table class="table"><tr><th>الحي / المنطقة</th><th>رسوم التوصيل</th><th>متاح للعملاء</th><th>الإدارة</th></tr>${STATE.deliveryAreas.map(a=>`<tr><td>${esc(a.name_ar)}</td><td>${sar(a.fee_sar)}</td><td>${a.active?'نعم':'لا'}</td><td><button class="btn secondary small" data-edit-delivery="${esc(a.id)}">تعديل</button></td></tr>`).join('')}</table></div>
 <h3>إضافة أو تعديل حي</h3><form id="deliveryAreaForm" class="stack"><input name="id" type="hidden" value="">
 <label>اسم الحي / المنطقة<input name="name_ar" class="field" required minlength="2" maxlength="120" placeholder="اسم الحي الذي تعتمد توصيله"></label>
 <label>رسوم التوصيل (بالريال)<input name="fee_sar" type="number" class="field" min="0" max="500" step="0.01" required placeholder="0.00"></label>
 <label>ترتيب الظهور<input name="sort_order" type="number" class="field" min="0" max="9999" value="100" required></label>
 <label><input name="active" type="checkbox"> متاح للعملاء — فعّل بعد اعتماد رسوم المنطقة</label>
 <p id="deliverySaveStatus" class="notice warn" hidden role="alert"></p>
 <button type="submit" class="btn">حفظ منطقة التوصيل</button></form></div>`;
if(STATE.adminTab==='customers')html+=`<div class="card"><h2>سجل العملاء</h2><p class="subtitle">لصاحب الصلاحية الأساسية فقط. لا تشارك هذه القائمة خارج أغراض التشغيل المشروعة.</p><button class="btn secondary small" data-load-customers>تحديث القائمة</button><div id="customerRows" class="tablewrap"><p class="empty">اضغط تحديث لقراءة القائمة من الخادم.</p></div></div>`;
if(STATE.adminTab==='events')html+=`<div class="stack">${STATE.events.map(e=>`<div class="card stack"><strong>${esc(e.event_type)} — ${esc(e.event_date)}</strong><div>${esc(e.district)} | ميزانية: ${sar(e.budget_sar)}</div><p>${esc(e.details)}</p><div>الحالة: ${esc(e.status)}</div><div class="choices">${[['contacted','تم التواصل'],['quoted','تم التسعير'],['approved','موافق عليه'],['closed','مغلق']].map(([s,n])=>`<button data-event-status="${s}" data-event="${esc(e.id)}" class="btn secondary small">${n}</button>`).join('')}</div></div>`).join('')}</div>`;
return html;
}
function render(){let body;switch(STATE.page){case 'shop':body=shop();break;case 'product':body=product();break;case 'design':body=design();break;case 'cart':body=cart();break;case 'account':body=account();break;case 'orders':body=orders();break;case 'events':body=events();break;case 'admin':body=admin();break;default:body=home()};$('app').innerHTML=`${header()}<main class="container">${STATE.error?`<div class="notice warn">${esc(STATE.error)}</div>`:''}${body}</main><footer>Tulipa Lovers · الطائف — نسخة تجريبية v0.9 · ${api.online?'موصول بخادم':'معاينة محلية'}</footer>${nav()}`}
async function reloadDeliveryAreas(){
 STATE.deliveryError='';
 try{STATE.deliveryAreas=api.online?await api.getDeliveryAreas():[]}
 catch(e){STATE.deliveryAreas=[];STATE.deliveryError='تعذر قراءة مناطق التوصيل. تأكد من تنفيذ إعداد قاعدة البيانات v0.7: '+e.message}
 if(!enabledDeliveryAreas().some(a=>a.id===STATE.selectedDeliveryArea))STATE.selectedDeliveryArea='';
}
async function reloadProducts(){
 STATE.products=api.online?await api.getProducts():DEMO;
 await reloadDeliveryAreas();
}
async function reloadOwnerNotifications({announce=false}={}){
 if(!isOwner()||!api.online){STATE.notifications=[];STATE.notificationError='';STATE.notificationsLoaded=false;return false;}
 const previous=new Set(STATE.notifications.map(n=>n.id));
 const loaded=await api.adminGetNotifications();
 if(!Array.isArray(loaded))throw new Error('استجابة الإشعارات غير صالحة');
 const fresh=STATE.notificationsLoaded?loaded.filter(n=>!n.read_at&&!previous.has(n.id)):[];
 const changed=JSON.stringify(STATE.notifications)!==JSON.stringify(loaded);
 STATE.notifications=loaded;
 STATE.notificationsLoaded=true;
 STATE.notificationError='';
 if(announce&&fresh.length)toast(`🔔 لديك ${fresh.length} طلب جديد في لوحة المالك`);
 return changed;
}
async function reloadCustomerData(){
 if(!api.currentUser())return;
 STATE.profile=await api.getProfile();
 const results=await Promise.allSettled([api.getOrders(),api.getLoyalty()]);
 STATE.orders=results[0].status==='fulfilled'?results[0].value:[];
 STATE.ledger=results[1].status==='fulfilled'?results[1].value:[];
 if(isOwner()){
  await reloadDeliveryAreas();
  try{STATE.events=await api.getEvents()}catch{STATE.events=[]}
  try{await reloadOwnerNotifications()}catch(e){STATE.notificationError='تعذّر قراءة إشعارات المالك. تحقق من تنفيذ SQL v0.9: '+e.message}
 }else{STATE.notifications=[];STATE.notificationError='';STATE.notificationsLoaded=false}
}
let notificationPollBusy=false;
async function pollOwnerNotifications(){
 if(notificationPollBusy||!api.online||!isOwner()||STATE.page!=='admin'||document.visibilityState==='hidden')return;
 notificationPollBusy=true;
 try{
  const olderIds=new Set(STATE.notifications.map(n=>n.id));
  const changed=await reloadOwnerNotifications({announce:true});
  if(changed){
   if(STATE.notifications.some(n=>!olderIds.has(n.id))){try{STATE.orders=await api.getOrders()}catch{ /* notification remains visible; order list can be refreshed manually */ }}
   if(STATE.adminTab==='notifications'||STATE.adminTab==='orders')render();
   else updateNotificationBadges(); // do not discard unsaved product/delivery edits
  }
 }catch(e){STATE.notificationError='تعذّر تحديث الإشعارات: '+e.message;if(STATE.adminTab==='notifications')render();}
 finally{notificationPollBusy=false}
}
function updateNotificationBadges(){
 const bell=document.querySelector?.('[data-open-notifications]');
 if(bell){const n=unreadCount();bell.setAttribute('aria-label',`إشعارات الطلبات${n?'، '+n+' غير مقروءة':''}`);const badge=bell.querySelector('.notif-badge');if(badge)badge.remove();if(n){const el=document.createElement('span');el.className='notif-badge';el.textContent=n>=100?'99+':String(n);bell.appendChild(el)}}
 const tab=document.querySelector?.('[data-admin-tab="notifications"]');
 if(tab)tab.textContent=`🔔 الإشعارات${unreadCount()?' ('+unreadCount()+')':''}`;
}
const notificationTimer=setInterval(pollOwnerNotifications,30000);
if(typeof notificationTimer?.unref==='function')notificationTimer.unref();

async function bootstrap(){
 try{
  const callback=await api.consumeAuthRedirect();
  if(callback){STATE.page='account';STATE.authMessage=callback.error||'تم تأكيد البريد الإلكتروني بنجاح';STATE.isPasswordRecovery=callback.type==='recovery';}
  await reloadProducts();
  if(api.currentUser())await reloadCustomerData();
 }catch(e){STATE.error='لم يتصل التطبيق بالخادم: '+e.message;STATE.products=[]} const page=window.location.hash.replace(/^#\//,'');if(['home','shop','product','design','cart','account','orders','events','admin'].includes(page))STATE.page=page;render();if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});}
function normPhone(phone){let p=String(phone).replace(/[\s()-]/g,'');if(p.startsWith('05'))p='+966'+p.slice(1);if(/^5\d{8}$/.test(p))p='+966'+p;if(!/^\+9665\d{8}$/.test(p))throw new Error('اكتب رقم جوال سعودي صحيح يبدأ بـ 05');return p}
async function handleCheckout(form){if(!api.online)throw new Error('اربط Supabase أولاً');if(!api.currentUser()){go('account');throw new Error('سجّل دخولك قبل إرسال الطلب')};if(!STATE.cart.length)throw new Error('السلة فارغة');const f=new FormData(form);const at=new Date(f.get('delivery_at'));if(Number.isNaN(at.getTime())||at.getTime()<Date.now()+2*60*60*1000)throw new Error('اختر موعدًا بعد ساعتين على الأقل');const area=enabledDeliveryAreas().find(a=>a.id===String(f.get('delivery_area_id')));if(!area)throw new Error('اختر حي توصيل متاحًا من القائمة قبل إرسال الطلب');const payload={p_request_id:sessionStorage.getItem('tulipa.pending_request')||crypto.randomUUID(),p_items:STATE.cart.map(c=>({product_id:c.product_id,quantity:c.quantity,customization:c.customization})),p_recipient_name:f.get('recipient_name'),p_recipient_phone:normPhone(f.get('recipient_phone')),p_district:area.name_ar,p_address:f.get('address'),p_delivery_at:at.toISOString(),p_customer_note:f.get('note'),p_redeem_points:STATE.pointsToRedeem};sessionStorage.setItem('tulipa.pending_request',payload.p_request_id);const id=await api.submitOrder(payload);sessionStorage.removeItem('tulipa.pending_request');STATE.cart=[];STATE.pointsToRedeem=0;saveCart();await reloadProducts();await reloadCustomerData();go('orders');toast('تم إنشاء طلبك على الخادم برقم '+String(id).slice(0,8))}
async function handleSubmit(e){const form=e.target;const id=form?.getAttribute?.('id');if(!id)return;e.preventDefault();const btn=form.querySelector('[type=submit],button:not([type])');const originalLabel=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='جاري التنفيذ...'}try{const f=new FormData(form);if(id==='searchForm'){STATE.query=String(f.get('query')||'').trim();render()}
else if(id==='emailSignUpForm'){
 const email=String(f.get('email')||'').trim().toLowerCase(),pass=String(f.get('password')||'');
 if(pass!==String(f.get('confirm_password')||''))throw new Error('تأكيد كلمة المرور غير متطابق');
 if(pass.length<8)throw new Error('كلمة المرور لا تقل عن 8 أحرف');
 STATE.authEmail=email;
 const result=await api.signUpWithEmail(email,pass,String(f.get('full_name')||'').trim());
 if(result?.access_token){STATE.authMessage='تم إنشاء الحساب وتسجيل الدخول. تأكيد البريد مستحسن قبل الاستخدام العام.';await reloadCustomerData()}
 else STATE.authMessage='إذا كان البريد مسموحًا بالإرسال، ستصلك رسالة تأكيد. افحص البريد الوارد والرسائل غير المرغوبة.';
 STATE.authMode='signin';render();toast(STATE.authMessage);
}
else if(id==='emailSignInForm'){
 const email=String(f.get('email')||'').trim().toLowerCase();
 await api.signInWithEmail(email,String(f.get('password')||''));
 STATE.authEmail=email;STATE.authMessage='';await reloadCustomerData();render();toast('تم تسجيل الدخول');
}
else if(id==='requestResetForm'){
 const email=String(f.get('email')||'').trim().toLowerCase();
 await api.requestPasswordReset(email);STATE.authEmail=email;
 STATE.authMessage='إذا كان البريد مسجّلًا وخدمة الإرسال مفعّلة، ستصلك رسالة إعادة التعيين.';STATE.authMode='signin';render();toast(STATE.authMessage);
}
else if(id==='resetPasswordForm'){
 const pass=String(f.get('password')||'');
 if(pass!==String(f.get('confirm_password')||''))throw new Error('تأكيد كلمة المرور غير متطابق');
 if(pass.length<8)throw new Error('كلمة المرور لا تقل عن 8 أحرف');
 await api.updatePassword(pass);STATE.isPasswordRecovery=false;STATE.authMessage='';render();toast('تم تغيير كلمة المرور');
}
else if(id==='profileForm'){await api.updateProfile(f.get('full_name'));await reloadCustomerData();render();toast('تم تحديث الاسم')}
else if(id==='emailForm'){await api.changeEmail(f.get('email'));toast('راجع بريدك لتأكيد التغيير وفق إعدادات Supabase')}
else if(id==='checkoutForm'){await handleCheckout(form)}
else if(id==='deliveryAreaForm'){
 if(!isOwner())throw new Error('تعديل رسوم التوصيل متاح للمالك فقط');
 const name=String(f.get('name_ar')||'').trim(),fee=Number(f.get('fee_sar')),sort=Number(f.get('sort_order'));
 if(name.length<2||name.length>120)throw new Error('اكتب اسم حي أو منطقة صالحًا');
 if(String(f.get('fee_sar')||'').trim()===''||!Number.isFinite(fee)||fee<0||fee>500)throw new Error('رسوم التوصيل يجب أن تكون بين 0 و500 ريال');
 if(!Number.isInteger(sort)||sort<0||sort>9999)throw new Error('ترتيب الحي يجب أن يكون رقمًا من 0 إلى 9999');
 await api.adminUpsertDeliveryArea({name_ar:name,fee_sar:fee,sort_order:sort,active:f.has('active')},f.get('id')||null);
 await reloadProducts();render();toast('حُفظت منطقة التوصيل بنجاح');
}
else if(id==='eventForm'){if(!api.currentUser())throw new Error('يجب تسجيل الدخول');const event={customer_id:api.currentUser().id,event_type:f.get('event_type'),event_date:f.get('event_date'),district:f.get('district'),budget_sar:f.get('budget')?Number(f.get('budget')):null,details:f.get('details')};await api.addEvent(event);toast('تم تسجيل طلب المناسبة لدى المحل');go('account')}
else if(id==='productForm'){if(!isOwner())throw new Error('ليست لديك صلاحية');const pid=f.get('id');const data={sku:f.get('sku'),title_ar:f.get('title_ar'),description_ar:f.get('description_ar'),category:f.get('category'),kind:f.get('kind'),price_sar:Number(f.get('price_sar')),stock_qty:Number(f.get('stock_qty')),image_path:String(f.get('image_path')||'bouquet_rose.jpg'),active:f.has('active'),featured:f.has('featured')};const file=f.get('new_image');if(file&&file.size){const status=$('productImageStatus');if(status)status.textContent='جاري رفع الصورة إلى مخزن توليبا...';data.image_path=await api.adminUploadProductImage(file)}await api.adminUpsertProduct(data,pid||null);await reloadProducts();render();toast('حُفظ المنتج'+(file&&file.size?' مع الصورة الجديدة':''))}
}catch(err){if(id==='deliveryAreaForm'){const status=$('deliverySaveStatus');if(status){status.textContent='تعذّر حفظ المنطقة: '+(err?.message||String(err));status.hidden=false}}if(id==='productForm'){const status=$('productSaveStatus');if(status){status.textContent='تعذّر حفظ المنتج: '+(err?.message||String(err));status.hidden=false;status.scrollIntoView?.({behavior:'smooth',block:'center'})}}eMsg(err)}finally{if(btn){btn.disabled=false;btn.textContent=originalLabel}}}
document.addEventListener('submit',handleSubmit);
document.addEventListener('change',e=>{if(e.target.id==='newProductImage'){const file=e.target.files?.[0],status=$('productImageStatus'),preview=$('productImagePreview');if(status)status.textContent=file?`تم اختيار ${file.name} (${(file.size/1048576).toFixed(2)} MB). سيتم رفعه عند الحفظ.`:'لم تُختَر صورة جديدة';if(file&&preview){if(window.tulipaImagePreviewUrl)URL.revokeObjectURL(window.tulipaImagePreviewUrl);window.tulipaImagePreviewUrl=URL.createObjectURL(file);preview.src=window.tulipaImagePreviewUrl;}return}if(e.target.id==='existingProductImage'){const preview=$('productImagePreview');if(preview&&!$('newProductImage')?.files?.length)preview.src=api.productImageUrl(e.target.value);return}if(e.target.id==='deliveryAreaSelect'){STATE.selectedDeliveryArea=String(e.target.value);updateDeliveryTotal();return}
 if(e.target.id==='redeemPoints'){STATE.pointsToRedeem=Number(e.target.value);const discount=STATE.pointsToRedeem/20;const d=$('summaryDiscount');if(d)d.textContent='− '+sar(discount);updateDeliveryTotal()}});
document.addEventListener('click',async e=>{const btn=e.target.closest('button');if(!btn)return;try{if(btn.hasAttribute('data-go'))return go(btn.dataset.go);if(btn.hasAttribute('data-auth-mode')){STATE.authMode=btn.dataset.authMode;STATE.authMessage='';return render()}if(btn.hasAttribute('data-cat')){STATE.category=btn.dataset.cat;return go('shop')}if(btn.hasAttribute('data-product')){STATE.productId=btn.dataset.product;return go('product')}if(btn.hasAttribute('data-add'))return add(btn.dataset.add);if(btn.hasAttribute('data-add-design'))return addDesign();if(btn.hasAttribute('data-fav')){const id=btn.dataset.fav;STATE.fav=STATE.fav.includes(id)?STATE.fav.filter(x=>x!==id):[...STATE.fav,id];localStorage.setItem('tulipa.fav',JSON.stringify(STATE.fav));return render()}if(btn.hasAttribute('data-design-key')){const {designKey:k,designValue:v}=btn.dataset;STATE.design[k]=k==='stems'?Number(v):k==='card'?v==='true':v;return render()}if(btn.hasAttribute('data-qty')){const i=Number(btn.dataset.qty);STATE.cart[i].quantity+=Number(btn.dataset.delta);const p=find(STATE.cart[i].product_id);if(STATE.cart[i].quantity>10||p?.kind==='fixed'&&STATE.cart[i].quantity>p.stock_qty){STATE.cart[i].quantity--;return toast('الحد المتاح 10 قطع أو أقل حسب المخزون')}if(STATE.cart[i].quantity<=0)STATE.cart.splice(i,1);saveCart();return render()}if(btn.hasAttribute('data-remove')){STATE.cart.splice(Number(btn.dataset.remove),1);saveCart();return render()}if(btn.hasAttribute('data-logout')){await api.signOut();STATE.isPasswordRecovery=false;STATE.authMessage='';STATE.profile=null;STATE.orders=[];STATE.ledger=[];STATE.notifications=[];STATE.notificationsLoaded=false;STATE.notificationError='';await reloadProducts();go('account');return toast('تم تسجيل الخروج')}if(btn.hasAttribute('data-open-notifications')){
 STATE.adminTab='notifications';go('admin');
 try{await reloadOwnerNotifications();render()}catch(e){STATE.notificationError='تعذر قراءة الإشعارات: '+e.message;render()}
 return;
}
if(btn.hasAttribute('data-refresh-notifications')){
 await reloadOwnerNotifications();STATE.orders=await api.getOrders();return render();
}
if(btn.hasAttribute('data-notification-read')){
 await api.adminMarkNotificationRead(btn.dataset.notificationRead);
 await reloadOwnerNotifications();render();return toast('تم تعليم الإشعار كمقروء');
}
if(btn.hasAttribute('data-mark-all-notifications')){
 if(!unreadCount())return;
 await api.adminMarkAllNotificationsRead();await reloadOwnerNotifications();render();return toast('تم تعليم الإشعارات كمقروءة');
}
if(btn.hasAttribute('data-notification-order')){
 const id=btn.dataset.notificationOrder;
 if(btn.dataset.notificationId)await api.adminMarkNotificationRead(btn.dataset.notificationId);
 await reloadOwnerNotifications();
 STATE.orders=await api.getOrders();STATE.adminTab='orders';render();
 const card=document.getElementById('order-'+id);
 if(card)card.scrollIntoView?.({behavior:'smooth',block:'center'});
 else toast('الطلب غير موجود حاليًا في سجل الطلبات');
 return;
}
if(btn.hasAttribute('data-admin-tab')){STATE.adminTab=btn.dataset.adminTab;return render()}if(btn.hasAttribute('data-edit-product')){const p=find(btn.dataset.editProduct);const f=$('productForm');if(!f)return;Object.entries(p).forEach(([k,v])=>{if(f.elements[k]){if(f.elements[k].type==='checkbox')f.elements[k].checked=!!v;else f.elements[k].value=v}});f.elements.id.value=p.id;if(f.elements.new_image)f.elements.new_image.value='';const preview=$('productImagePreview');if(preview)preview.src=api.productImageUrl(p.image_path);const status=$('productImageStatus');if(status)status.textContent='يمكنك اختيار صورة جديدة أو الإبقاء على الصورة الحالية.';f.scrollIntoView({behavior:'smooth'});return}if(btn.hasAttribute('data-edit-delivery')){
 const area=STATE.deliveryAreas.find(a=>a.id===btn.dataset.editDelivery),f=$('deliveryAreaForm');if(!area||!f)return;
 for(const field of ['id','name_ar','fee_sar','sort_order'])if(f.elements[field])f.elements[field].value=area[field];
 if(f.elements.active)f.elements.active.checked=area.active;f.scrollIntoView?.({behavior:'smooth'});return;
}if(btn.hasAttribute('data-load-customers')){const rows=await api.adminGetCustomers();$('customerRows').innerHTML=`<table class="table"><tr><th>الاسم</th><th>الجوال</th><th>البريد</th><th>الصلاحية</th></tr>${rows.map(u=>`<tr><td>${esc(u.full_name)}</td><td>${esc(u.phone)}</td><td>${esc(u.email)}</td><td>${esc(u.role)}</td></tr>`).join('')}</table>`;return}if(btn.hasAttribute('data-online-pay')){const id=btn.dataset.onlinePay;btn.disabled=true;const result=await api.moyasarTestPayment(id,'create');if(result.status==='test_paid'){await reloadCustomerData();render();return toast('نجح الدفع الاختباري فقط؛ الطلب لا يزال غير مدفوع ماليًا')}if(result.url){const paymentUrl=new URL(result.url);if(paymentUrl.protocol!=='https:'||!paymentUrl.hostname.endsWith('.moyasar.com'))throw new Error('رابط الدفع غير موثوق');window.location.assign(result.url);return;}throw new Error('لم تجهز صفحة الدفع')}if(btn.hasAttribute('data-verify-pay')){const result=await api.moyasarTestPayment(btn.dataset.verifyPay,'verify');await reloadCustomerData();render();return toast(result.status==='test_paid'?'نجح الاختبار فقط، دون تحصيل أو تغيير الحالة المالية':result.status==='review'?'العملية تحتاج مراجعة المالك':'لم يؤكد مزود الخدمة الدفع بعد')}if(btn.hasAttribute('data-admin-status')){const st=btn.dataset.adminStatus;await api.adminSetOrderStatus(btn.dataset.order,{status:st});await reloadCustomerData();render();return toast('تم تحديث حالة الطلب')}if(btn.hasAttribute('data-admin-paid')){if(!confirm('هل تحققت من استلام المبلغ النقدي فعلًا؟'))return;await api.adminRecordCashPayment(btn.dataset.adminPaid);await reloadCustomerData();render();return toast('سُجل تأكيد التحصيل النقدي')}if(btn.hasAttribute('data-event-status')){await api.adminSetEventStatus(btn.dataset.event,btn.dataset.eventStatus);await reloadCustomerData();render();return toast('تم تحديث المناسبة')}}catch(err){eMsg(err)}});
bootstrap();
