const NAME='tulipa-shell-v07';
const SHELL=['./','./index.html','./styles.css','./app.js','./api.js','./config.js','./icons/icon.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(NAME).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 const url=new URL(req.url);
 if(url.pathname.endsWith('config.js')) return; // do not cache backend configuration across redeploys
 event.respondWith(fetch(req).then(r=>{if(r.ok){const c=r.clone();caches.open(NAME).then(cache=>cache.put(req,c));}return r}).catch(()=>caches.match(req)));
});
